#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Interface (site local) para a equipe rodar o GISS sem linha de comando.

Sobe um servidor Flask em http://127.0.0.1:5002 e serve a página `ui.html`.
Por baixo, chama os scripts JÁ VALIDADOS (encerrar.py e baixar_documentos.py)
como subprocesso e transmite o andamento ao vivo para a tela (SSE).

O servidor roda ESCONDIDO (sem janela preta), em segundo plano: fechar o navegador ou a
janela do programa NÃO interrompe uma execução — é só abrir de novo que a tela reconecta.

Modos de abrir:
  • python app.py              -> garante o servidor escondido e abre no NAVEGADOR
  • python app_janela.py       -> garante o servidor escondido e abre numa JANELA (pywebview)
  • python app.py --servidor   -> o servidor em si (é o que o lançador sobe escondido)
  • python app.py --no-browser -> servidor em primeiro plano, no console (para testes)
"""
import csv
import json
import os
import queue
import socket
import subprocess
import sys
import tempfile
import threading
import time
import urllib.request
import webbrowser
from datetime import date, datetime
from pathlib import Path

from flask import Flask, request, Response, jsonify, send_file

BASE = Path(__file__).resolve().parent          # pasta 'sistema' (código)
sys.path.insert(0, str(BASE))
from encerrar import ler_clientes, competencia_alvo  # reaproveita o que já existe

ROOT = BASE.parent                               # pasta do usuário (cliente.xlsx + documentos)
LOGS = BASE / "logs"                             # logs/prints ficam ESCONDIDOS aqui
LOGS.mkdir(exist_ok=True)
PLANILHA = ROOT / "cliente.xlsx"
DOCS = ROOT / "documentos"
# 5002 (e não mais 5001): o .bat antigo derruba quem estiver na 5001 toda vez que abre,
# o que matava uma execução em andamento. Na 5002 o servidor sobrevive e é reaproveitado.
PORTA = 5002
URL = f"http://127.0.0.1:{PORTA}"
_SEM_JANELA = getattr(subprocess, "CREATE_NO_WINDOW", 0)   # roda programas sem abrir console


def _ler_versao():
    try:
        return (BASE / "versao_local.txt").read_text(encoding="utf-8").strip()
    except Exception:
        return ""


VERSAO_CODIGO = _ler_versao()   # versão do código que ESTE processo carregou


def _python_console():
    """python.exe (não pythonw.exe) para os scripts: o print deles vai para a tela ao vivo."""
    exe = Path(sys.executable)
    alt = exe.with_name("python.exe")
    return str(alt if alt.exists() else exe)

app = Flask(__name__)

# Estado de UMA execução por vez (uso local, single-user).
_lock = threading.Lock()
estado = {"proc": None, "fila": None, "rodando": False, "linhas": [], "op": None, "cancelar": False}


# ---------------------------------------------------------------- páginas
@app.route("/")
def index():
    return send_file(str(BASE / "ui.html"))


@app.route("/api/clientes")
def api_clientes():
    try:
        cs = ler_clientes(str(PLANILHA))
    except Exception as e:
        return jsonify({"erro": f"Erro lendo {PLANILHA.name}: {e}"}), 500
    return jsonify([{"i": i, "nome": c["apelido"] or c["login"], "resp": (c.get("responsavel") or "").strip()}
                    for i, c in enumerate(cs)])


@app.route("/api/inicio")
def api_inicio():
    """Dados iniciais: competência padrão (mês anterior) e se há execução rodando."""
    label, _ = competencia_alvo(None)
    with _lock:
        rodando = estado["rodando"]
        op = estado["op"]
    return jsonify({"competencia": label, "planilha": PLANILHA.name, "rodando": rodando, "op": op,
                    "versao": VERSAO_CODIGO, "pid": os.getpid()})


@app.route("/api/log")
def api_log():
    """Log completo da execução atual (para repovoar a tela ao recarregar)."""
    with _lock:
        return jsonify({"linhas": list(estado["linhas"]), "rodando": estado["rodando"], "op": estado["op"]})


# ---------------------------------------------------------------- execução
def _escrever_temp(indices):
    """Grava um CSV temporário (COM cabeçalho) só com os clientes escolhidos."""
    cs = ler_clientes(str(PLANILHA))
    sel = [cs[i] for i in indices if 0 <= i < len(cs)] if indices else cs
    fd, caminho = tempfile.mkstemp(suffix=".csv", prefix="_sel_", dir=str(LOGS))
    with os.fdopen(fd, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f)
        w.writerow(["EMPRESA", "CNPJ", "LOGIN", "SENHA", "RESPONSAVEL"])   # cabeçalho p/ leitura
        for c in sel:
            w.writerow([c["apelido"], c.get("cnpj", ""), c["login"], c["senha"], c.get("responsavel", "")])
    return caminho, len(sel)


def _emitir(linha):
    """Registra uma linha no log e empurra para a tela ao vivo. (chamar com _lock)"""
    estado["linhas"].append(linha)
    if estado["fila"]:
        estado["fila"].put(linha)


def _rodar(passos, temp_path):
    """Executa os passos (um ou mais comandos) em sequência, transmitindo tudo
    para a MESMA tela. Só finaliza (__FIM__) depois do último passo.
    Cada passo é {"cmd": [...], "cabecalho": "▶ ..."}."""
    env = dict(os.environ, PYTHONUNBUFFERED="1", PYTHONUTF8="1", PYTHONIOENCODING="utf-8")
    for passo in passos:
        with _lock:
            if estado["cancelar"]:
                break
            if passo.get("cabecalho"):
                _emitir(passo["cabecalho"])
        try:
            proc = subprocess.Popen(passo["cmd"], cwd=str(LOGS), env=env, stdout=subprocess.PIPE,
                                    stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL, text=True,
                                    encoding="utf-8", errors="replace", bufsize=1,
                                    creationflags=_SEM_JANELA)
        except Exception as e:
            with _lock:
                _emitir(f"ERRO ao iniciar: {e}")
            break
        with _lock:
            estado["proc"] = proc
        for line in proc.stdout:
            line = line.rstrip("\n")
            if not line:
                continue
            with _lock:
                _emitir(line)
        proc.wait()
        with _lock:
            estado["proc"] = None
            parar = estado["cancelar"]
        if parar:
            break
    with _lock:
        estado["rodando"] = False
        estado["proc"] = None
        estado["cancelar"] = False
        if estado["fila"]:
            estado["fila"].put("__FIM__")
    try:
        os.remove(temp_path)
    except Exception:
        pass


@app.route("/api/rodar", methods=["POST"])
def api_rodar():
    d = request.get_json(force=True) or {}
    with _lock:
        if estado["rodando"]:
            return jsonify({"erro": "Já existe uma execução em andamento."}), 409

    op = d.get("operacao")
    comp = (d.get("competencia") or "").strip()
    indices = d.get("clientes") or []
    if not indices:
        return jsonify({"erro": "Selecione pelo menos um cliente."}), 400

    # O que encerrar: Prestador e Tomador (padrão), só Prestador ou só Tomador.
    modalidade = (d.get("modalidade") or "ambos").strip().lower()
    if modalidade not in ("ambos", "prestador", "tomador"):
        return jsonify({"erro": f"Opção inválida de encerramento: '{modalidade}'."}), 400
    modrot = {"ambos": "", "prestador": " · só Prestador", "tomador": " · só Tomador"}[modalidade]

    # Data de pagamento (só vale para competência VENCIDA). Vazio = hoje.
    data_pag = (d.get("data_pagamento") or "").strip() or date.today().strftime("%d/%m/%Y")
    try:
        data_pag = datetime.strptime(data_pag, "%d/%m/%Y").strftime("%d/%m/%Y")
    except ValueError:
        return jsonify({"erro": f"Data de pagamento inválida: '{data_pag}'. Use DD/MM/AAAA."}), 400

    temp_path, n = _escrever_temp(indices)
    comprot = comp or "mês anterior"
    pagrot = f" · se vencida, pagamento em {data_pag}"

    # --headless: encerramento SEM abrir janela do navegador (roda escondido)
    def cmd_encerrar():
        c = [_python_console(), str(BASE / "encerrar.py"), "--clientes", temp_path, "--headless",
             "--data-pagamento", data_pag, "--modalidade", modalidade]
        if comp:
            c += ["--competencia", comp]
        if d.get("apurar"):
            c += ["--apurar"]
        return c

    # --saida: salva os documentos na pasta 'documentos' da raiz (fora de 'sistema')
    def cmd_baixar():
        c = [_python_console(), str(BASE / "baixar_documentos.py"), "--clientes", temp_path,
             "--saida", str(DOCS)]
        if comp:
            c += ["--competencia", comp]
        if d.get("xml"):
            c += ["--xml"]
        return c

    if op == "encerrar":
        rot = "Encerrar (DE VERDADE)" if d.get("apurar") else "Simular encerramento"
        passos = [{"cmd": cmd_encerrar(), "cabecalho": f"▶ {rot}{modrot} · competência {comprot} · {n} cliente(s){pagrot}"}]
        rotulo = rot
    elif op == "baixar":
        rotulo = "Baixar documentos"
        passos = [{"cmd": cmd_baixar(), "cabecalho": f"▶ {rotulo} · competência {comprot} · {n} cliente(s)"}]
    elif op == "encerrar_baixar":
        # Faz os dois em sequência, com a MESMA seleção de clientes (um só arquivo temporário).
        rot1 = "Encerrar (DE VERDADE)" if d.get("apurar") else "Simular encerramento"
        passos = [
            {"cmd": cmd_encerrar(), "cabecalho": f"▶ 1/2 · {rot1}{modrot} · competência {comprot} · {n} cliente(s){pagrot}"},
            {"cmd": cmd_baixar(),   "cabecalho": f"▶ 2/2 · Baixar documentos · competência {comprot} · {n} cliente(s)"},
        ]
        rotulo = "Encerrar e baixar"
    else:
        try:
            os.remove(temp_path)
        except Exception:
            pass
        return jsonify({"erro": "Operação inválida."}), 400

    with _lock:
        estado["rodando"] = True
        estado["cancelar"] = False
        estado["linhas"] = []
        estado["fila"] = queue.Queue()
        estado["op"] = op
    threading.Thread(target=_rodar, args=(passos, temp_path), daemon=True).start()
    return jsonify({"ok": True, "clientes": n, "rotulo": rotulo})


@app.route("/api/stream")
def api_stream():
    def gen():
        with _lock:
            f = estado["fila"]
        if f is None:
            yield "data: __FIM__\n\n"
            return
        while True:
            try:
                l = f.get(timeout=25)
            except queue.Empty:
                yield ": ping\n\n"          # mantém a conexão viva
                continue
            yield f"data: {l}\n\n"
            if l == "__FIM__":
                break
    return Response(gen(), mimetype="text/event-stream",
                    headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})


@app.route("/api/parar", methods=["POST"])
def api_parar():
    with _lock:
        estado["cancelar"] = True     # impede seguir para o próximo passo da sequência
        proc = estado["proc"]
    if not proc:
        return jsonify({"ok": True, "detalhe": "nada rodando"})
    try:
        # mata a árvore (o Python + o Chromium do Playwright) — Windows
        subprocess.run(["taskkill", "/F", "/T", "/PID", str(proc.pid)],
                       capture_output=True, creationflags=_SEM_JANELA)
    except Exception:
        try:
            proc.terminate()
        except Exception:
            pass
    with _lock:
        estado["linhas"].append("■ Execução interrompida pelo usuário.")
        if estado["fila"]:
            estado["fila"].put("■ Execução interrompida pelo usuário.")
    return jsonify({"ok": True})


@app.route("/api/abrir-pasta", methods=["POST"])
def api_abrir_pasta():
    DOCS.mkdir(exist_ok=True)
    try:
        os.startfile(str(DOCS))   # Windows: abre no Explorer
    except Exception as e:
        return jsonify({"erro": str(e)}), 500
    return jsonify({"ok": True, "pasta": str(DOCS)})


@app.route("/api/desligar", methods=["POST"])
def api_desligar():
    """Desliga o servidor (o lançador usa para trocar por uma versão nova). Recusa se houver
    execução em andamento — nunca derruba trabalho no meio."""
    with _lock:
        if estado["rodando"]:
            return jsonify({"erro": "Há uma execução em andamento."}), 409
    threading.Timer(0.3, lambda: os._exit(0)).start()
    return jsonify({"ok": True})


# ---------------------------------------------------------------- lançador (sem janela preta)
def _api(caminho, metodo="GET", timeout=3):
    req = urllib.request.Request(URL + caminho, method=metodo, data=b"{}" if metodo == "POST" else None,
                                 headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8"))


def _porta_ocupada():
    with socket.socket() as s:
        s.settimeout(0.5)
        return s.connect_ex(("127.0.0.1", PORTA)) == 0


def _info_servidor(tentativas=3):
    """/api/inicio do servidor que já está na porta (ou None se não responder)."""
    for _ in range(tentativas):
        try:
            return _api("/api/inicio")
        except Exception:
            time.sleep(1)
    return None


def _esperar(cond, segundos):
    fim = time.monotonic() + segundos
    while time.monotonic() < fim:
        if cond():
            return True
        time.sleep(0.3)
    return False


def _matar_quem_esta_na_porta():
    out = subprocess.run(["netstat", "-ano", "-p", "TCP"], capture_output=True, text=True,
                         errors="replace", creationflags=_SEM_JANELA).stdout
    for linha in out.splitlines():
        p = linha.split()
        if len(p) >= 5 and p[1].endswith(f":{PORTA}") and p[3].upper() == "LISTENING":
            subprocess.run(["taskkill", "/F", "/T", "/PID", p[4]], capture_output=True,
                           creationflags=_SEM_JANELA)


def _subir_servidor():
    """Sobe `app.py --servidor` ESCONDIDO e independente desta janela (se a janela preta
    fechar, ele continua). O que ele escreveria no console vai para logs/servidor.log."""
    log = LOGS / "servidor.log"
    try:
        if log.exists() and log.stat().st_size > 2_000_000:
            log.replace(LOGS / "servidor.anterior.log")
    except Exception:
        pass
    env = dict(os.environ, PYTHONUNBUFFERED="1", PYTHONUTF8="1", PYTHONIOENCODING="utf-8")
    flags = _SEM_JANELA | getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
    with open(log, "a", encoding="utf-8") as f:
        kw = dict(cwd=str(BASE), env=env, stdin=subprocess.DEVNULL, stdout=f, stderr=subprocess.STDOUT,
                  close_fds=True)
        cmd = [_python_console(), str(BASE / "app.py"), "--servidor"]
        try:   # se o Windows deixar, solta do "grupo" do .bat para nada derrubar o servidor junto
            subprocess.Popen(cmd, creationflags=flags | getattr(subprocess, "CREATE_BREAKAWAY_FROM_JOB", 0), **kw)
        except OSError:
            subprocess.Popen(cmd, creationflags=flags, **kw)


def garantir_servidor():
    """Deixa UM servidor do GISS rodando escondido e devolve a URL (ou None se falhar).
    - já tem um com execução em andamento -> reaproveita (NUNCA derruba trabalho no meio)
    - já tem um parado, na versão atual    -> reaproveita
    - parado em versão velha, ou travado   -> troca por um novo"""
    if _porta_ocupada():
        info = _info_servidor()
        if info and info.get("rodando"):
            print("  O GISS já está rodando uma execução — abrindo a tela dela...")
            return URL
        if info and str(info.get("versao")) == _ler_versao():
            return URL
        print("  Reiniciando o GISS para usar a versão nova..." if info else
              "  O GISS anterior não respondeu — reiniciando...")
        try:
            _api("/api/desligar", "POST")
        except Exception:
            pass
        if not _esperar(lambda: not _porta_ocupada(), 6):
            info = _info_servidor(1)
            if info and info.get("rodando"):
                return URL                     # começou uma execução nesse meio-tempo
            _matar_quem_esta_na_porta()
            _esperar(lambda: not _porta_ocupada(), 6)
    _subir_servidor()
    if _esperar(lambda: _info_servidor(1) is not None, 40):
        return URL
    print(f"  ERRO: o GISS não conseguiu abrir. Detalhes em: {LOGS / 'servidor.log'}")
    return None


def fechar_console():
    """Fecha a janela preta do atalho do GISS (o servidor segue escondido). Só age se fomos
    abertos pelo .bat do GISS (cmd.exe com o título 'GISS - servidor'); senão não mexe."""
    if os.name != "nt":
        return
    try:
        import ctypes
        k32 = ctypes.windll.kernel32
        buf = ctypes.create_unicode_buffer(1024)
        k32.GetConsoleTitleW(buf, 1024)
        if "GISS - SERVIDOR" not in buf.value.upper():
            return
        pai = os.getppid()
        nome = subprocess.run(["tasklist", "/FI", f"PID eq {pai}", "/FO", "CSV", "/NH"],
                              capture_output=True, text=True, errors="replace",
                              creationflags=_SEM_JANELA).stdout.lower()
        if "cmd.exe" not in nome:
            return
        print("\n  Pronto! O GISS fica rodando escondido — esta janela fecha sozinha.")
        print("  Pode fechar o navegador à vontade: é só abrir o atalho de novo que a tela volta.")
        time.sleep(2.5)
        subprocess.run(["taskkill", "/F", "/PID", str(pai)], capture_output=True, creationflags=_SEM_JANELA)
        k32.FreeConsole()
    except Exception:
        pass


def _servir():
    """O servidor em si (rodando escondido, sem console)."""
    print(f"[{time.strftime('%d/%m/%Y %H:%M:%S')}] GISS versão {VERSAO_CODIGO} em {URL} (pid {os.getpid()})",
          flush=True)
    app.run(host="127.0.0.1", port=PORTA, threaded=True)


def main():
    if "--servidor" in sys.argv:
        _servir()
        return
    if "--no-browser" in sys.argv:                 # testes: servidor no console, em primeiro plano
        print(f"GISS — interface em {URL}  (Ctrl+C para encerrar)")
        app.run(host="127.0.0.1", port=PORTA, threaded=True)
        return
    url = garantir_servidor()
    if not url:
        return                                     # deixa a janela preta aberta com o erro
    webbrowser.open(url)
    fechar_console()


if __name__ == "__main__":
    main()
