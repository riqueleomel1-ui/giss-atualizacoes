#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Interface (site local) para a equipe rodar o GISS sem linha de comando.

Sobe um servidor Flask em http://127.0.0.1:5001 e serve a página `ui.html`.
Por baixo, chama os scripts JÁ VALIDADOS (encerrar.py e baixar_documentos.py)
como subprocesso e transmite o andamento ao vivo para a tela (SSE).

Modos de abrir:
  • python app.py           -> sobe o servidor e abre no NAVEGADOR
  • python app.py --no-browser -> só sobe o servidor (usado pelo modo janela)
  • python app_janela.py     -> abre numa JANELA de aplicativo (pywebview)
"""
import csv
import os
import queue
import subprocess
import sys
import tempfile
import threading
import webbrowser
from pathlib import Path

from flask import Flask, request, Response, jsonify, send_file

BASE = Path(__file__).resolve().parent          # pasta 'sistema' (código)
sys.path.insert(0, str(BASE))
from encerrar import ler_clientes, competencia_alvo  # reaproveita o que já existe

ROOT = BASE.parent                               # pasta do usuário (cliente.xlsx + documentos)
LOGS = BASE / "logs"                             # logs/prints ficam ESCONDIDOS aqui
LOGS.mkdir(exist_ok=True)
PLANILHA = ROOT / "cliente.xlsx"
DOCS = ROOT / "documentos"
PORTA = 5001

app = Flask(__name__)

# Estado de UMA execução por vez (uso local, single-user).
_lock = threading.Lock()
estado = {"proc": None, "fila": None, "rodando": False, "linhas": [], "op": None, "cancelar": False}


# ---------------------------------------------------------------- páginas
@app.route("/")
def index():
    return send_file(str(BASE / "ui.html"))


@app.route("/api/clientes")
def api_clientes():
    try:
        cs = ler_clientes(str(PLANILHA))
    except Exception as e:
        return jsonify({"erro": f"Erro lendo {PLANILHA.name}: {e}"}), 500
    return jsonify([{"i": i, "nome": c["apelido"] or c["login"], "resp": (c.get("responsavel") or "").strip()}
                    for i, c in enumerate(cs)])


@app.route("/api/inicio")
def api_inicio():
    """Dados iniciais: competência padrão (mês anterior) e se há execução rodando."""
    label, _ = competencia_alvo(None)
    try:
        versao = (BASE / "versao_local.txt").read_text(encoding="utf-8").strip()
    except Exception:
        versao = ""
    with _lock:
        rodando = estado["rodando"]
        op = estado["op"]
    return jsonify({"competencia": label, "planilha": PLANILHA.name, "rodando": rodando, "op": op, "versao": versao})


@app.route("/api/log")
def api_log():
    """Log completo da execução atual (para repovoar a tela ao recarregar)."""
    with _lock:
        return jsonify({"linhas": list(estado["linhas"]), "rodando": estado["rodando"], "op": estado["op"]})


# ---------------------------------------------------------------- execução
def _escrever_temp(indices):
    """Grava um CSV temporário (COM cabeçalho) só com os clientes escolhidos."""
    cs = ler_clientes(str(PLANILHA))
    sel = [cs[i] for i in indices if 0 <= i < len(cs)] if indices else cs
    fd, caminho = tempfile.mkstemp(suffix=".csv", prefix="_sel_", dir=str(LOGS))
    with os.fdopen(fd, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f)
        w.writerow(["EMPRESA", "CNPJ", "LOGIN", "SENHA", "RESPONSAVEL"])   # cabeçalho p/ leitura
        for c in sel:
            w.writerow([c["apelido"], c.get("cnpj", ""), c["login"], c["senha"], c.get("responsavel", "")])
    return caminho, len(sel)


def _emitir(linha):
    """Registra uma linha no log e empurra para a tela ao vivo. (chamar com _lock)"""
    estado["linhas"].append(linha)
    if estado["fila"]:
        estado["fila"].put(linha)


def _rodar(passos, temp_path):
    """Executa os passos (um ou mais comandos) em sequência, transmitindo tudo
    para a MESMA tela. Só finaliza (__FIM__) depois do último passo.
    Cada passo é {"cmd": [...], "cabecalho": "▶ ..."}."""
    env = dict(os.environ, PYTHONUNBUFFERED="1", PYTHONUTF8="1", PYTHONIOENCODING="utf-8")
    for passo in passos:
        with _lock:
            if estado["cancelar"]:
                break
            if passo.get("cabecalho"):
                _emitir(passo["cabecalho"])
        try:
            proc = subprocess.Popen(passo["cmd"], cwd=str(LOGS), env=env, stdout=subprocess.PIPE,
                                    stderr=subprocess.STDOUT, text=True, encoding="utf-8",
                                    errors="replace", bufsize=1)
        except Exception as e:
            with _lock:
                _emitir(f"ERRO ao iniciar: {e}")
            break
        with _lock:
            estado["proc"] = proc
        for line in proc.stdout:
            line = line.rstrip("\n")
            if not line:
                continue
            with _lock:
                _emitir(line)
        proc.wait()
        with _lock:
            estado["proc"] = None
            parar = estado["cancelar"]
        if parar:
            break
    with _lock:
        estado["rodando"] = False
        estado["proc"] = None
        estado["cancelar"] = False
        if estado["fila"]:
            estado["fila"].put("__FIM__")
    try:
        os.remove(temp_path)
    except Exception:
        pass


@app.route("/api/rodar", methods=["POST"])
def api_rodar():
    d = request.get_json(force=True) or {}
    with _lock:
        if estado["rodando"]:
            return jsonify({"erro": "Já existe uma execução em andamento."}), 409

    op = d.get("operacao")
    comp = (d.get("competencia") or "").strip()
    indices = d.get("clientes") or []
    if not indices:
        return jsonify({"erro": "Selecione pelo menos um cliente."}), 400

    temp_path, n = _escrever_temp(indices)
    comprot = comp or "mês anterior"

    # --headless: encerramento SEM abrir janela do navegador (roda escondido)
    def cmd_encerrar():
        c = [sys.executable, str(BASE / "encerrar.py"), "--clientes", temp_path, "--headless"]
        if comp:
            c += ["--competencia", comp]
        if d.get("apurar"):
            c += ["--apurar"]
        return c

    # --saida: salva os documentos na pasta 'documentos' da raiz (fora de 'sistema')
    def cmd_baixar():
        c = [sys.executable, str(BASE / "baixar_documentos.py"), "--clientes", temp_path,
             "--saida", str(DOCS)]
        if comp:
            c += ["--competencia", comp]
        if d.get("xml"):
            c += ["--xml"]
        return c

    if op == "encerrar":
        rot = "Encerrar (DE VERDADE)" if d.get("apurar") else "Simular encerramento"
        passos = [{"cmd": cmd_encerrar(), "cabecalho": f"▶ {rot} · competência {comprot} · {n} cliente(s)"}]
        rotulo = rot
    elif op == "baixar":
        rotulo = "Baixar documentos"
        passos = [{"cmd": cmd_baixar(), "cabecalho": f"▶ {rotulo} · competência {comprot} · {n} cliente(s)"}]
    elif op == "encerrar_baixar":
        # Faz os dois em sequência, com a MESMA seleção de clientes (um só arquivo temporário).
        rot1 = "Encerrar (DE VERDADE)" if d.get("apurar") else "Simular encerramento"
        passos = [
            {"cmd": cmd_encerrar(), "cabecalho": f"▶ 1/2 · {rot1} · competência {comprot} · {n} cliente(s)"},
            {"cmd": cmd_baixar(),   "cabecalho": f"▶ 2/2 · Baixar documentos · competência {comprot} · {n} cliente(s)"},
        ]
        rotulo = "Encerrar e baixar"
    else:
        try:
            os.remove(temp_path)
        except Exception:
            pass
        return jsonify({"erro": "Operação inválida."}), 400

    with _lock:
        estado["rodando"] = True
        estado["cancelar"] = False
        estado["linhas"] = []
        estado["fila"] = queue.Queue()
        estado["op"] = op
    threading.Thread(target=_rodar, args=(passos, temp_path), daemon=True).start()
    return jsonify({"ok": True, "clientes": n, "rotulo": rotulo})


@app.route("/api/stream")
def api_stream():
    def gen():
        with _lock:
            f = estado["fila"]
        if f is None:
            yield "data: __FIM__\n\n"
            return
        while True:
            try:
                l = f.get(timeout=25)
            except queue.Empty:
                yield ": ping\n\n"          # mantém a conexão viva
                continue
            yield f"data: {l}\n\n"
            if l == "__FIM__":
                break
    return Response(gen(), mimetype="text/event-stream",
                    headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})


@app.route("/api/parar", methods=["POST"])
def api_parar():
    with _lock:
        estado["cancelar"] = True     # impede seguir para o próximo passo da sequência
        proc = estado["proc"]
    if not proc:
        return jsonify({"ok": True, "detalhe": "nada rodando"})
    try:
        # mata a árvore (o Python + o Chromium do Playwright) — Windows
        subprocess.run(["taskkill", "/F", "/T", "/PID", str(proc.pid)],
                       capture_output=True)
    except Exception:
        try:
            proc.terminate()
        except Exception:
            pass
    with _lock:
        estado["linhas"].append("■ Execução interrompida pelo usuário.")
        if estado["fila"]:
            estado["fila"].put("■ Execução interrompida pelo usuário.")
    return jsonify({"ok": True})


@app.route("/api/abrir-pasta", methods=["POST"])
def api_abrir_pasta():
    DOCS.mkdir(exist_ok=True)
    try:
        os.startfile(str(DOCS))   # Windows: abre no Explorer
    except Exception as e:
        return jsonify({"erro": str(e)}), 500
    return jsonify({"ok": True, "pasta": str(DOCS)})


def main():
    abrir = "--no-browser" not in sys.argv
    if abrir:
        threading.Timer(1.2, lambda: webbrowser.open(f"http://127.0.0.1:{PORTA}")).start()
    print(f"GISS — interface em http://127.0.0.1:{PORTA}  (Ctrl+C para encerrar)")
    app.run(host="127.0.0.1", port=PORTA, threaded=True)


if __name__ == "__main__":
    main()
