#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Auto-atualizador do GISS.

Roda ANTES do programa abrir (chamado pelo .bat). Checa no GitHub se existe uma
versao mais nova do CODIGO e, se houver, baixa e substitui os arquivos de codigo
(dentro de 'sistema/'). NAO mexe no navegador/Python, nem na cliente.xlsx, nem em
'documentos'. Se nao houver internet ou der qualquer erro, so segue com a versao atual.

Como publicar uma atualizacao (voce/eu): no repositorio giss-atualizacoes, subir um
'codigo.zip' novo (com os arquivos de codigo) e aumentar o numero em 'versao.txt'.
"""
import io
import zipfile
import urllib.request
from pathlib import Path

BASE = Path(__file__).resolve().parent            # pasta 'sistema'
USUARIO = "riqueleomel1-ui"
REPO = "giss-atualizacoes"
BRANCH = "main"
URL_VERSAO = f"https://raw.githubusercontent.com/{USUARIO}/{REPO}/{BRANCH}/versao.txt"
URL_CODIGO = f"https://raw.githubusercontent.com/{USUARIO}/{REPO}/{BRANCH}/codigo.zip"
VERSAO_LOCAL = BASE / "versao_local.txt"


def _versao_local() -> int:
    try:
        return int(VERSAO_LOCAL.read_text(encoding="utf-8").strip())
    except Exception:
        return 0


def _baixar(url: str, timeout: int = 20) -> bytes:
    req = urllib.request.Request(url, headers={"User-Agent": "GISS-updater"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read()


def main():
    try:
        remota = int(_baixar(URL_VERSAO).decode("utf-8", "replace").strip())
    except Exception as e:
        print(f"  (nao consegui checar atualizacao: {str(e)[:60]} - seguindo com a versao atual)")
        return
    local = _versao_local()
    if remota <= local:
        print(f"  (programa atualizado - versao {local})")
        return
    print(f"  Baixando atualizacao: versao {local} -> {remota} ...")
    try:
        dados = _baixar(URL_CODIGO, timeout=90)
        with zipfile.ZipFile(io.BytesIO(dados)) as z:
            # seguranca: so extrai arquivos simples (sem caminho pra fora de 'sistema')
            for nome in z.namelist():
                if nome.endswith("/") or ".." in nome or nome.startswith(("/", "\\")):
                    continue
                z.extract(nome, BASE)
        VERSAO_LOCAL.write_text(str(remota), encoding="utf-8")
        print(f"  Atualizado para a versao {remota}! ")
    except Exception as e:
        print(f"  (falha ao baixar a atualizacao: {str(e)[:60]} - seguindo com a versao atual)")


if __name__ == "__main__":
    main()
