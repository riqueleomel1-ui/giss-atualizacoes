#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Baixador de documentos do GissOnline Guarulhos (Fase 2) — PARTE 1: GUIAS (DAM).

Por cliente e competência, baixa as guias e organiza em pastas:
  <saida>/<Cliente>/<MM.AAAA>/<Tomador|Prestador>/ISS <MODALIDADE> <MM.AAAA> - R$ <valor>.pdf

Reaproveita o login/navegação já validados de encerrar.py.
As próximas partes (comprovante, XMLs, relatório) entram depois de validarmos esta.

Uso:
    python baixar_documentos.py --clientes cliente.xlsx --competencia 07/2026
    python baixar_documentos.py --clientes cliente.xlsx                 # mês anterior
    python baixar_documentos.py --clientes cliente.xlsx --limite 1      # teste
Opções: --saida <pasta> (padrão: documentos), --headless
"""

import argparse
import calendar
import sys
import zipfile
from pathlib import Path

try:
    from playwright.sync_api import sync_playwright, TimeoutError as PWTimeout
except ImportError:
    sys.exit("Playwright não instalado. Rode:  pip install -r requirements.txt  &&  playwright install chromium")

# reaproveita o que já foi validado no encerrar.py
from encerrar import (ler_clientes, competencia_alvo, logar, selecionar_empresa,
                      esperar_operacao, fechar_modais)

MESES_PT = {1: "janeiro", 2: "fevereiro", 3: "março", 4: "abril", 5: "maio", 6: "junho",
            7: "julho", 8: "agosto", 9: "setembro", 10: "outubro", 11: "novembro", 12: "dezembro"}


def _nome_pasta(nome: str) -> str:
    """Sanitiza o nome do cliente para virar pasta (remove caracteres inválidos no Windows)."""
    limpo = "".join(c for c in nome if c not in '<>:"/\\|?*').strip().rstrip(".")
    return limpo[:100] or "cliente"


# Expande o mês na tela de Conta Corrente (clica na linha do mês).
JS_EXPANDIR_MES = r"""
(mesNome) => {
  const norm = s => (s||'').replace(/\s+/g,' ').trim().toLowerCase();
  const rows = Array.from(document.querySelectorAll('tr'));
  const linha = rows.find(r => norm(r.textContent).startsWith(mesNome));
  if(!linha) return false;
  linha.click();
  return true;
}
"""

# Lista as guias visíveis (linhas com botão Imprimir): modalidade + valor + índice do botão.
JS_LISTAR_GUIAS = r"""
() => {
  const norm = s => (s||'').replace(/\s+/g,' ').trim();
  const btns = Array.from(document.querySelectorAll('button[title="Imprimir"]'));
  return btns.map((b, i) => {
    const tr = b.closest('tr');
    const cels = tr ? Array.from(tr.querySelectorAll('td')).map(td => norm(td.textContent)) : [];
    const modal = (cels.find(c => /prestador|tomador/i.test(c)) || '');
    const das = cels.some(c => c.trim().toUpperCase() === 'DAS');
    const moedas = cels.filter(c => /^\d{1,3}(\.\d{3})*,\d{2}$/.test(c));
    const valor = moedas.find(v => v !== '0,00') || (moedas[0] || '');
    // botão desabilitado = guia VENCIDA/substituída (não imprime) -> deve ser pulada
    const disabled = !!b.disabled || b.getAttribute('disabled') !== null;
    const vencida = cels.some(c => /vencid/i.test(c));
    return { idx: i, modalidade: modal, valor: valor, das: das, disabled: disabled, vencida: vencida };
  });
}
"""


def baixar_guias_cliente(page, nome, iso, comp_dot, pasta_cliente):
    """Baixa as guias (DAM) do cliente para a competência. Retorna lista de resultados."""
    ano = iso[:4]
    mes_nome = MESES_PT[int(iso[5:7])]
    resultados = []

    # 1. Conta Corrente -> Consultar Conta
    page.evaluate("location.hash = '#/operacao/conta-corrente/consultar-conta'")
    try:
        page.wait_for_selector("select", timeout=15000)  # combo do ano
    except PWTimeout:
        raise RuntimeError("não abriu o Conta Corrente")
    page.wait_for_timeout(800)
    fechar_modais(page)

    # 2. seleciona o ano da competência
    try:
        page.locator("select").first.select_option(label=ano)
        page.wait_for_timeout(1000)
    except Exception:
        pass

    # 3. expande o mês
    if not page.evaluate(JS_EXPANDIR_MES, mes_nome):
        return [{"modalidade": "-", "status": "erro", "detalhe": f"mês {mes_nome} não encontrado"}]
    page.wait_for_timeout(1200)

    # 4. lista as guias. Pula: DAS (Simples paga no DAS, sem DAM municipal) e guias com o
    #    botão Imprimir DESABILITADO (vencidas/substituídas -> não imprimem, dariam timeout).
    todas = page.evaluate(JS_LISTAR_GUIAS)
    guias = [g for g in todas if not g.get("das") and not g.get("disabled")]
    if not guias:
        if any(g.get("disabled") or g.get("vencida") for g in todas):
            return [{"modalidade": "-", "status": "só vencida", "detalhe": "guia vencida/substituída (não imprimível)"}]
        return [{"modalidade": "-", "status": "sem guia", "detalhe": "nenhuma guia municipal (Simples/DAS)"}]

    # 5. baixa cada guia com o nome certo, na pasta da modalidade
    for g in guias:
        modal = (g.get("modalidade") or "").strip().upper()
        if "PREST" in modal:
            modal = "PRESTADOR"
        elif "TOMAD" in modal:
            modal = "TOMADOR"
        else:
            modal = modal or "GUIA"
        valor = (g.get("valor") or "").strip() or "0,00"
        subpasta = pasta_cliente / comp_dot / modal.capitalize()
        subpasta.mkdir(parents=True, exist_ok=True)
        arquivo = subpasta / f"ISS {modal} {comp_dot} - R$ {valor}.pdf"
        try:
            with page.expect_download(timeout=15000) as dl_info:
                page.evaluate("(i)=>document.querySelectorAll('button[title=\"Imprimir\"]')[i].click()", g["idx"])
            dl_info.value.save_as(str(arquivo))
            resultados.append({"modalidade": modal, "status": "baixado", "detalhe": arquivo.name})
        except PWTimeout:
            resultados.append({"modalidade": modal, "status": "erro", "detalhe": "download não veio"})
    return resultados


# Expande a linha da competência apurada no Histórico (Bootstrap collapse).
JS_EXPANDIR_COMPETENCIA = r"""
(mesNome) => {
  const norm = s => (s||'').replace(/\s+/g,' ').trim().toLowerCase();
  const rows = Array.from(document.querySelectorAll('tr'));
  const linha = rows.find(r => norm(r.textContent).startsWith(mesNome) && /sim/i.test(r.textContent));
  if(!linha) return false;
  linha.click();
  return true;
}
"""

# --- Apurações ESCOPADAS à competência expandida -----------------------------
# A lista do Histórico é uma tabela de meses ("julho | Sim | ..."). Ao clicar num mês
# APURADO ("Sim"), ele expande e mostra logo ABAIXO as linhas da apuração (uma por
# botão "Extrato Apuração"), até a linha do PRÓXIMO mês. Cada linha tem:
#   td[0]=Geração (dd/mm/aaaa) | td[1]=Modalidade ("Prestador"/"Tomador"/VAZIA) | valores...
# Modalidade VAZIA = Tomador SEM movimento ("linha sem nome de identificação").
# Escopar à competência (em vez de conferir o mês no detalhe) evita 2 armadilhas:
#   (a) o AngularJS só vincula a competência da linha-em-branco quando o page.pdf força
#       o render — logo não dá pra ler do detalhe; (b) outro mês pode estar expandido.
_JS_MESES = "['janeiro','fevereiro','março','marco','abril','maio','junho','julho','agosto','setembro','outubro','novembro','dezembro']"

JS_APURACOES_COMPETENCIA = (r"""
(mesNome) => {
  const norm = s => (s||'').replace(/\s+/g,' ').trim();
  const meses = """ + _JS_MESES + r""";
  const ehData = s => /^\d{2}\/\d{2}\/\d{4}$/.test(s);
  const rows = Array.from(document.querySelectorAll('tr'));
  const i0 = rows.findIndex(r => norm(r.textContent).toLowerCase().startsWith(mesNome)
                                 && /sim/i.test(r.textContent));
  if (i0 < 0) return { ok: false, itens: [] };
  const itens = [];
  for (let i = i0 + 1; i < rows.length; i++) {
    const t = norm(rows[i].textContent).toLowerCase();
    if (meses.some(m => t.startsWith(m))) break;                 // chegou no próximo mês
    const tds = Array.from(rows[i].querySelectorAll('td')).map(td => norm(td.textContent));
    if (!rows[i].querySelector('button[title="Extrato Apuração"]') || !ehData(tds[0])) continue;
    const nums = tds.filter(x => /^\d{1,3}(\.\d{3})*,\d{2}$/.test(x));
    itens.push({ modal: tds[1] || '', geracao: tds[0], mov: nums.some(x => x !== '0,00') });
  }
  return { ok: true, itens: itens };
}
""")

JS_CLICAR_APURACAO = (r"""
([mesNome, ord]) => {
  const norm = s => (s||'').replace(/\s+/g,' ').trim();
  const meses = """ + _JS_MESES + r""";
  const ehData = s => /^\d{2}\/\d{2}\/\d{4}$/.test(s);
  const rows = Array.from(document.querySelectorAll('tr'));
  const i0 = rows.findIndex(r => norm(r.textContent).toLowerCase().startsWith(mesNome)
                                 && /sim/i.test(r.textContent));
  if (i0 < 0) return false;
  let k = -1;
  for (let i = i0 + 1; i < rows.length; i++) {
    const t = norm(rows[i].textContent).toLowerCase();
    if (meses.some(m => t.startsWith(m))) break;
    const btn = rows[i].querySelector('button[title="Extrato Apuração"]');
    const tds = Array.from(rows[i].querySelectorAll('td')).map(td => norm(td.textContent));
    if (!btn || !ehData(tds[0])) continue;
    k++;
    if (k === ord) { btn.click(); return true; }
  }
  return false;
}
""")

# Detecta MOVIMENTO na apuração aberta (Detalhamento): algum valor de moeda != 0,00.
JS_TEM_MOVIMENTO = r"""
() => {
  const t = ((document.querySelector('main')||document.body).innerText || '');
  const nums = t.match(/\d{1,3}(\.\d{3})*,\d{2}/g) || [];
  return nums.some(n => n !== '0,00');
}
"""

# Modalidade da apuração aberta, pela seção do Detalhamento (ignora o menu lateral).
# Tolerante a caixa/acentos e a texto extra ("Serviços Tomados de Terceiros" etc.);
# se só uma das expressões aparecer no conteúdo principal, usa ela.
JS_MODALIDADE_DETALHE = r"""
() => {
  const norm = s => (s||'').replace(/\s+/g,' ').trim().toLowerCase();
  const naNav = e => e.closest('nav, .sidebar, [role=navigation], a, .navegacao_lista_item') !== null;
  for (const e of document.querySelectorAll('h1,h2,h3,h4,h5,legend,th,strong,b,label')) {
    if (naNav(e)) continue;
    const t = norm(e.textContent);
    if (/^servi[çc]os?\s+tomad/.test(t) || t === 'tomador') return 'TOMADOR';
    if (/^servi[çc]os?\s+prestad/.test(t) || t === 'prestador') return 'PRESTADOR';
  }
  const main = norm((document.querySelector('main')||document.body).innerText);
  const tom = /servi[çc]os?\s+tomad/.test(main);
  const pre = /servi[çc]os?\s+prestad/.test(main);
  if (tom && !pre) return 'TOMADOR';
  if (pre && !tom) return 'PRESTADOR';
  return '';
}
"""

# Competência mostrada no Detalhamento aberto (campo "Extrato da Competência").
# USA textContent (innerText às vezes não pega o valor recém-vinculado pelo AngularJS).
JS_COMPETENCIA_ABERTA = r"""
() => {
  const t = ((document.querySelector('main')||document.body).textContent || '');
  const m = t.match(/\d{2}\/\d{4}/g) || [];   // ex.: 07/2026
  return m;
}
"""

# Snippet do Detalhamento (diagnóstico).
JS_DETALHE_DUMP = r"""
() => {
  const norm = s => (s||'').replace(/\s+/g,' ').trim();
  return norm((document.querySelector('main')||document.body).textContent).slice(0,900);
}
"""


def baixar_comprovantes_cliente(page, iso, comp_dot, pasta_cliente):
    """Salva o comprovante (PDF) por modalidade e retorna (resultados, modalidades_com_movimento)."""
    ano = iso[:4]
    mes_nome = MESES_PT[int(iso[5:7])]
    resultados = []
    com_movimento = set()

    def ir_e_expandir():
        page.evaluate("location.hash = '#/operacao/apuracao/historico'")
        page.wait_for_selector("select", timeout=15000)
        page.wait_for_timeout(700)
        fechar_modais(page)
        try:
            page.locator("select").first.select_option(label=ano)
            page.wait_for_timeout(900)
        except Exception:
            pass
        ok = page.evaluate(JS_EXPANDIR_COMPETENCIA, mes_nome)
        page.wait_for_timeout(1200)
        return ok

    def _data_key(s):
        # "04/08/2026" -> 20260804 (para escolher a apuração mais recente entre reaberturas)
        try:
            d, m, a = s.split("/")
            return int(a) * 10000 + int(m) * 100 + int(d)
        except Exception:
            return 0

    if not ir_e_expandir():
        return [{"modalidade": "-", "status": "sem apuração", "detalhe": f"{mes_nome} não apurado"}], com_movimento
    res = page.evaluate(JS_APURACOES_COMPETENCIA, mes_nome) or {"ok": False, "itens": []}
    if not res.get("ok") or not res.get("itens"):
        return [{"modalidade": "-", "status": "sem apuração", "detalhe": f"{mes_nome} não apurado"}], com_movimento

    # DECIDE, sem clicar, qual apuração salvar por modalidade (linha nomeada > com movimento
    # > mais recente). Linha com Modalidade VAZIA = Tomador SEM movimento (regra do usuário).
    plano = {}   # modal -> {"ord","mov","blank","data"}
    for idx, it in enumerate(res["itens"]):
        col = (it.get("modal") or "").upper()
        blank = col not in ("TOMADOR", "PRESTADOR")
        modal = col if not blank else "TOMADOR"
        mov = bool(it.get("mov"))
        data = _data_key(it.get("geracao") or "")
        prev = plano.get(modal)
        if prev:
            melhor = ((prev["blank"] and not blank)
                      or (prev["blank"] == blank and mov and not prev["mov"])
                      or (prev["blank"] == blank and mov == prev["mov"] and data > prev["data"]))
            if not melhor:
                continue
        plano[modal] = {"ord": idx, "mov": mov, "blank": blank, "data": data}

    # Abre e salva o comprovante (PDF) de cada modalidade escolhida.
    for modal in ("PRESTADOR", "TOMADOR"):
        pl = plano.get(modal)
        if not pl:
            continue
        ir_e_expandir()
        if not page.evaluate(JS_CLICAR_APURACAO, [mes_nome, pl["ord"]]):
            resultados.append({"modalidade": modal, "status": "erro", "detalhe": "não achou o extrato na competência"})
            continue
        try:
            page.wait_for_selector("text=DETALHAMENTO DA APURAÇÃO", timeout=15000)
        except PWTimeout:
            page.wait_for_timeout(1500)
        page.wait_for_timeout(2000)   # deixa o AngularJS vincular os valores antes do PDF
        subpasta = pasta_cliente / comp_dot / modal.capitalize()
        subpasta.mkdir(parents=True, exist_ok=True)
        arquivo = subpasta / f"COMPROVANTE {modal} - {comp_dot}.pdf"
        try:
            page.pdf(path=str(arquivo), format="A4", print_background=True)
            resultados.append({"modalidade": modal,
                               "status": "salvo" + ("" if pl["mov"] else " (sem mov)"),
                               "detalhe": arquivo.name})
            if pl["mov"]:
                com_movimento.add(modal)
        except Exception as e:
            resultados.append({"modalidade": modal, "status": "erro", "detalhe": f"page.pdf exige headless ({str(e)[:40]})"})

    if not resultados:
        resultados.append({"modalidade": "-", "status": "sem apuração", "detalhe": f"{mes_nome} sem extrato"})
    return resultados, com_movimento


# Seleciona uma opção (por texto) no <select> que a contém, forçando o change do AngularJS.
# (O select_option do Playwright não atualiza esses selects AngularJS de forma confiável.)
JS_SELECIONAR_OPCAO = r"""
(texto) => {
  const norm = s => (s||'').replace(/\s+/g,' ').trim().toLowerCase();
  const alvo = norm(texto);
  for (const s of Array.from(document.querySelectorAll('select'))) {
    const opt = Array.from(s.options).find(o => norm(o.textContent) === alvo);
    if (opt) {
      s.value = opt.value;
      s.selectedIndex = opt.index;
      s.dispatchEvent(new Event('change', {bubbles: true}));
      s.dispatchEvent(new Event('input', {bubbles: true}));
      if (window.angular) { try { window.angular.element(s).triggerHandler('change'); } catch(e){} }
      return true;
    }
  }
  return false;
}
"""


# Diagnóstico: estado de todos os <select> (opções, valor atual, ng-model).
JS_DUMP_SELECTS = r"""
() => JSON.stringify(Array.from(document.querySelectorAll('select')).map(s => ({
  valor: s.value,
  selecionado: (s.options[s.selectedIndex] || {}).textContent || '',
  opcoes: Array.from(s.options).map(o => (o.textContent||'').trim()),
  disabled: s.disabled,
  ngModel: s.getAttribute('ng-model') || ''
})), null, 1)
"""


def _selecionar_por_opcao(page, texto):
    """Seleciona uma opção (por texto visível) no <select> que a contém."""
    selects = page.locator("select")
    for i in range(selects.count()):
        s = selects.nth(i)
        try:
            opts = [o.strip() for o in s.locator("option").all_inner_texts()]
        except Exception:
            continue
        for o in opts:
            if o.lower() == texto.strip().lower():
                s.select_option(label=o)
                return True
    return False


def _dismiss_ok(page):
    """Fecha o diálogo de sucesso 'Exportar declaração' (botão Ok)."""
    for nome in ("Ok", "OK"):
        try:
            b = page.get_by_role("button", name=nome, exact=True)
            if b.count() and b.first.is_visible():
                b.first.click(timeout=1500)
                page.wait_for_timeout(400)
                return
        except Exception:
            pass


# Estado do processamento para [formato, modalidade, competência]: 'pronto' (Processado),
# 'processando' (só Não Processado) ou '' (nenhuma linha). A COMPETÊNCIA é obrigatória no
# casamento (a grade acumula pedidos de MESES anteriores — sem isso pegava o mês errado).
# A linha mostra Início/Fim: PDF="08/2026", XML="01/08/2026...31/08/2026" (ambos contêm "08/2026").
# Casa a competência SÓ nas colunas Início/Fim (célula = "MM/AAAA" ou "DD/MM/AAAA"),
# IGNORANDO a coluna "Data do Processamento" (que tem hora, com ':') — senão um export de
# 07/2026 processado em 06/08/2026 casaria com "08/2026" pela data de processamento.
_JS_COMP_BATE = r"""
  const compBate = (r, comp) => {
    const p = comp.split('/'); const mm = p[0], aaaa = p[1];
    const cels = Array.from(r.querySelectorAll('td, [role=gridcell], [role=cell]'))
                   .map(c => (c.textContent||'').replace(/\s+/g,' ').trim());
    return cels.some(c => {
      if (c.includes(':')) return false;                 // Data de Processamento -> ignora
      let x = c.match(/^(\d{2})\/(\d{4})$/);              // Competência MM/AAAA
      if (x) return x[1]===mm && x[2]===aaaa;
      let y = c.match(/^(\d{2})\/(\d{2})\/(\d{4})$/);     // Início/Fim do Período DD/MM/AAAA
      if (y) return y[2]===mm && y[3]===aaaa;
      return false;
    });
  };
"""

JS_SITUACAO_PROC = (r"""
([formato, modal, comp]) => {
  const norm = s => (s||'').replace(/\s+/g,' ').trim().toLowerCase();
  const f = formato.toLowerCase(), m = modal.toLowerCase();
""" + _JS_COMP_BATE + r"""
  const rows = Array.from(document.querySelectorAll('tr, [role=row]')).filter(x => {
    const t = norm(x.textContent);
    return t && t.includes(f) && t.includes(m) && compBate(x, comp);
  });
  for(const r of rows){ const t = norm(r.textContent);
    if(t.includes('processado') && !t.includes('não processado') && !t.includes('nao processado')) return 'pronto';
  }
  return rows.length ? 'processando' : '';
}
""")

# Clica o download de uma linha "Processado" que casa [formato, modalidade, COMPETÊNCIA].
# A grade ACUMULA solicitações de MESES anteriores; casar SÓ formato+modalidade pegava o
# mês errado (ex.: baixava 07/2026 no lugar de 08/2026). A competência é obrigatória.
# Entre as que casam, clica no primeiro botão de download HABILITADO (situacaoProcessamento==4).
JS_BAIXAR_PROC = (r"""
([formato, modal, comp]) => {
  const norm = s => (s||'').replace(/\s+/g,' ').trim().toLowerCase();
  const f = formato.toLowerCase(), m = modal.toLowerCase();
""" + _JS_COMP_BATE + r"""
  const rows = Array.from(document.querySelectorAll('tr, [role=row]')).filter(x => {
    const t = norm(x.textContent);
    return t.includes('processado') && !t.includes('não processado') && !t.includes('nao processado')
      && t.includes(f) && t.includes(m) && compBate(x, comp);
  });
  const habil = b => b && !b.disabled && b.getAttribute('disabled') === null
                  && !(b.className||'').includes('disabled');
  for (const r of rows) {
    const cand = Array.from(r.querySelectorAll('a, button, [ng-click]'));
    const dl = cand.find(b => /download|baixar/i.test((b.title||'')+' '+(b.getAttribute('ng-click')||'')));
    if (habil(dl)) { dl.click(); return true; }
  }
  return false;
}
""")

# Diagnóstico: despeja as linhas da grade de Processamentos (o que o JS realmente enxerga).
JS_DUMP_GRID = r"""
() => {
  const norm = s => (s||'').replace(/\s+/g,' ').trim();
  const rows = Array.from(document.querySelectorAll('tr, [role=row], .grid tr, ul li, .table-row'));
  const info = rows.map(r => ({tag: r.tagName, role: r.getAttribute('role')||'', cls: (r.className||'').slice(0,40), txt: norm(r.textContent).slice(0,140)}))
                   .filter(x => x.txt);
  return JSON.stringify(info.slice(0, 30), null, 1);
}
"""

# Diagnóstico: HTML da última coluna (Ações) da linha "Processado com Sucesso" que casa.
JS_DEBUG_ACOES = r"""
([formato, modal, comp]) => {
  const norm = s => (s||'').replace(/\s+/g,' ').trim().toLowerCase();
  const f = formato.toLowerCase(), m = modal.toLowerCase();
  const r = Array.from(document.querySelectorAll('tr, [role=row]')).find(x => {
    const t = norm(x.textContent);
    return t.includes('processado') && !t.includes('não processado') && !t.includes('nao processado')
      && t.includes(f) && t.includes(m) && t.includes(comp);
  });
  if(!r) return 'sem linha pronta';
  const cels = r.querySelectorAll('td, [role=gridcell], [role=cell]');
  return cels.length ? cels[cels.length-1].innerHTML : ('LINHA: '+r.outerHTML.slice(0,600));
}
"""

# Clica o PRIMEIRO botão "Excluir solicitação" habilitado da grade (qualquer linha).
# Usado em loop DEPOIS de baixar, pra ESVAZIAR a lista de exportações do cliente (a grade só
# mostra 50/página, então deixá-la vazia evita qualquer estouro no futuro). Confiável: não
# depende de casar competência (que às vezes deixava 1 pedido recém-criado pra trás).
# Só remove PEDIDOS de exportação — não mexe em notas nem apuração (são regeneráveis).
JS_CLICAR_EXCLUIR = r"""
() => {
  const bs = Array.from(document.querySelectorAll('button[title="Excluir solicitação"]'));
  const b = bs.find(x => !x.disabled && x.getAttribute('disabled') === null && !(x.className||'').includes('disabled'));
  if (b) { b.click(); return true; }
  return false;
}
"""


def _confirmar_sim(page):
    """Confirma o diálogo 'Excluir Solicitação' clicando em 'Sim'. O portal usa SweetAlert
    v1 (classe '.sweet-alert' — NÃO contém 'swal'!); tratamos v1 e v2."""
    try:
        ok = page.evaluate(r"""() => {
          const sa = document.querySelector('.sweet-alert.visible, .sweet-alert.showSweetAlert, .sweet-alert, .swal2-popup, .swal-modal, [class*="swal"]');
          if(!sa) return false;
          const btns = Array.from(sa.querySelectorAll('button'));
          const b = btns.find(x => (x.textContent||'').trim().toLowerCase() === 'sim')
                 || sa.querySelector('button.confirm, .sa-confirm-button-container button, button.swal2-confirm')
                 || (btns.length ? btns[btns.length-1] : null);   // último = confirmar (ordem Não|Sim)
          if(b){ b.click(); return true; }
          return false;
        }""")
        if ok:
            return True
    except Exception:
        pass
    try:
        b = page.get_by_role("button", name="Sim", exact=True)
        if b.count() and b.first.is_visible():
            b.first.click(timeout=2000)
            return True
    except Exception:
        pass
    return False


_JS_DIALOGO = "document.querySelector('.sweet-alert.visible, .sweet-alert.showSweetAlert, .swal2-popup, .swal-modal')"


def _excluir_export(page):
    """ESVAZIA a lista de exportações do cliente (apaga todos os pedidos, um a um). Chamado
    depois de baixar. Só remove PEDIDOS de exportação — notas/apuração ficam intactas."""
    for _ in range(60):   # teto de segurança (grade tem no máx. algumas dezenas)
        try:
            clicou = page.evaluate(JS_CLICAR_EXCLUIR)
        except Exception:
            break
        if not clicou:
            break
        # espera o "Tem certeza?" REALMENTE aparecer antes de clicar Sim
        try:
            page.wait_for_function("() => { const s=" + _JS_DIALOGO + "; return s && /certeza|excluir/i.test(s.textContent||''); }",
                                   timeout=4000)
        except PWTimeout:
            pass
        _confirmar_sim(page)
        # espera o diálogo SUMIR (deleção concluída) antes de ir pro próximo
        try:
            page.wait_for_function("() => !(" + _JS_DIALOGO + ")", timeout=4000)
        except PWTimeout:
            pass
        page.wait_for_timeout(500)


def exportar_declaracao(page, lado, formato, comp_label, destino, nome_arquivo):
    """Solicita a exportação (XML ou XLSX) por competência e baixa quando concluir. Retorna dict."""
    rota = "servicos-prestados" if lado == "prestador" else "servicos-comprados"
    page.evaluate(f"location.hash = '#/operacao/{rota}/exportar-declaracao-nfs'")
    try:
        page.wait_for_selector("select", timeout=15000)
    except PWTimeout:
        return {"status": "erro", "detalhe": "tela Exportar não abriu"}
    page.wait_for_timeout(800)
    fechar_modais(page)
    # espera as opções do Método (Competência) carregarem antes de mexer nos selects
    try:
        page.wait_for_function(
            "() => Array.from(document.querySelectorAll('select option')).some(o => /compet|per[ií]odo/i.test(o.textContent))",
            timeout=12000)
    except PWTimeout:
        pass

    # Método e valores dependem do FORMATO:
    #   XML  -> método "Período"     (Inicial/Final = datas DD/MM/AAAA do mês da competência)
    #   PDF  -> método "Competência" (Inicial/Final = MM/AAAA)
    mes_str, ano_str = comp_label.split("/")
    if formato == "XML":
        metodo = "Período"
        ultimo = calendar.monthrange(int(ano_str), int(mes_str))[1]
        val_inicial, val_final = f"01/{mes_str}/{ano_str}", f"{ultimo:02d}/{mes_str}/{ano_str}"
        campos_sel = 'input[placeholder="00/00/0000"], input[placeholder="DD/MM/AAAA"]'
    else:
        metodo = "Competência"
        val_inicial = val_final = comp_label
        campos_sel = 'input[placeholder="00/0000"], input[placeholder="MM/AAAA"]'

    if not page.evaluate(JS_SELECIONAR_OPCAO, formato):   # Formato do Arquivo
        try: page.screenshot(path=f"debug_export_{lado}_{formato}.png", full_page=True)
        except Exception: pass
        return {"status": "erro", "detalhe": f"formato {formato} não encontrado"}
    page.wait_for_timeout(1200)  # deixa o formato assentar
    # seleciona o método e espera o(s) campo(s) aparecer(em)
    for _ in range(6):
        page.evaluate(JS_SELECIONAR_OPCAO, metodo)
        page.wait_for_timeout(900)
        if page.locator(campos_sel).count() > 0:
            break
        page.wait_for_timeout(500)
    campos = page.locator(campos_sel)
    if campos.count() == 0:
        try:
            page.screenshot(path=f"debug_export_{lado}_{formato}.png", full_page=True)
            with open(f"debug_selects_{lado}_{formato}.txt", "w", encoding="utf-8") as fh:
                fh.write(page.evaluate(JS_DUMP_SELECTS) or "")
        except Exception:
            pass
        return {"status": "erro", "detalhe": f"método {metodo} não abriu o campo (ver debug_selects_*.txt)"}
    # preenche Inicial e Final (fecha o calendário que abre ao focar)
    try:
        campos.nth(0).fill(val_inicial)
        page.keyboard.press("Escape")
    except Exception:
        pass
    if campos.count() > 1:
        try:
            campos.nth(1).fill(val_final)
            page.keyboard.press("Escape")
        except Exception:
            pass
    page.wait_for_timeout(400)
    page.keyboard.press("Escape")        # fecha calendário que pode cobrir o botão Solicitar
    page.wait_for_timeout(300)
    clicou_solicitar = False
    for _ in range(4):
        try:
            btn = page.get_by_role("button", name="Solicitar processamento", exact=True)
            if btn.count() and btn.first.is_visible():
                btn.first.click(timeout=3000)
                clicou_solicitar = True
                break
        except Exception:
            pass
        # fallback: clique direto via JS (ignora overlay/calendário por cima do botão)
        try:
            if page.evaluate("""() => {
                const b = Array.from(document.querySelectorAll('button'))
                  .find(x => /solicitar\\s+processamento/i.test(x.textContent||''));
                if (b) { b.click(); return true; } return false; }"""):
                clicou_solicitar = True
                break
        except Exception:
            pass
        page.wait_for_timeout(700)
    if not clicou_solicitar:
        return {"status": "erro", "detalhe": "botão Solicitar não encontrado"}
    page.wait_for_timeout(1500)
    _dismiss_ok(page)  # dispensa "Exportar declaração ... Ok"

    modal = "Prestador" if lado == "prestador" else "Tomador"
    # inclui a COMPETÊNCIA no casamento da grade (senão pega pedido de outro mês acumulado).
    # comp_label = "MM/AAAA"; serve p/ PDF (Início/Fim = MM/AAAA) e p/ XML (datas contêm MM/AAAA).
    par = [formato, modal, comp_label]
    rota_url = f"#/operacao/{rota}/exportar-declaracao-nfs"

    def recarregar_grade():
        # sai da rota e volta -> força o AngularJS a re-buscar a grade (setar o mesmo hash não recarrega)
        page.evaluate("location.hash = '#/operacao/apuracao'")
        page.wait_for_timeout(500)
        page.evaluate(f"location.hash = '{rota_url}'")
        try:
            page.wait_for_selector("select", timeout=15000)
        except PWTimeout:
            pass
        page.wait_for_timeout(1200)
        page.evaluate(JS_SELECIONAR_OPCAO, "50")  # 50 por página -> não perde a linha em outra página
        page.wait_for_timeout(900)
        fechar_modais(page)

    processado = False
    for _ in range(30):  # ~ até 5 min (exportação assíncrona)
        recarregar_grade()
        if (page.evaluate(JS_SITUACAO_PROC, par) or "") == "pronto":
            processado = True
            break
        page.wait_for_timeout(6000)
    if not processado:
        try:
            page.screenshot(path=f"debug_export_{lado}_{formato}.png", full_page=True)
            with open(f"debug_grid_{lado}_{formato}.txt", "w", encoding="utf-8") as fh:
                fh.write(page.evaluate(JS_DUMP_GRID) or "")
        except Exception:
            pass
        return {"status": "timeout", "detalhe": "não achou 'Processado' (ver debug_grid_*.txt)"}

    def _fin(res):
        # DEPOIS de baixar com sucesso, apaga o pedido de exportação (mantém a grade enxuta
        # p/ não estourar a paginação com o tempo). Só o pedido some — notas/apuração intactas.
        # Recarrega a grade ANTES de excluir: logo após o download ela fica num estado em que
        # o clique no "Excluir" não pega; com a grade fresca (como numa navegação nova) funciona.
        if res.get("status") == "baixado":
            try:
                recarregar_grade()
                _excluir_export(page)
            except Exception:
                pass
        return res

    destino.mkdir(parents=True, exist_ok=True)
    try:
        # a grade acumula solicitações antigas; às vezes o 1º clique não dispara o
        # download (linha sem botão habilitado ainda) -> tenta de novo recarregando.
        d = None
        for tentativa in range(3):
            try:
                with page.expect_download(timeout=25000) as dl:
                    clicou = page.evaluate(JS_BAIXAR_PROC, par)
                if not clicou:
                    raise PWTimeout("nenhum botão de download habilitado")
                d = dl.value
                break
            except PWTimeout:
                if tentativa == 2:
                    raise
                recarregar_grade()
        if formato == "PDF":
            # o portal entrega o PDF de resumo DENTRO de um zip -> extrai o PDF
            tmp = destino / "_tmp_pdf.zip"
            d.save_as(str(tmp))
            dados = None
            try:
                with zipfile.ZipFile(tmp) as z:
                    pdfs = [n for n in z.namelist() if n.lower().endswith(".pdf")]
                    dados = z.read(pdfs[0]) if pdfs else b""
            except zipfile.BadZipFile:
                tmp.replace(destino / nome_arquivo)  # já era um PDF de verdade (replace sobrescreve)
                return _fin({"status": "baixado", "detalhe": nome_arquivo})
            try:
                tmp.unlink()  # agora o zip já está FECHADO -> pode apagar (Windows)
            except Exception:
                pass
            if dados:
                (destino / nome_arquivo).write_bytes(dados)
                return _fin({"status": "baixado", "detalhe": nome_arquivo})
            return {"status": "vazio", "detalhe": "sem notas (zip vazio)"}
        else:
            # XML (zip com os XMLs) -> só salva se tiver conteúdo (senão o cliente não teve movimento)
            tmp = destino / "_tmp_xml.zip"
            d.save_as(str(tmp))
            try:
                with zipfile.ZipFile(tmp) as z:
                    tem_conteudo = any(not n.endswith("/") for n in z.namelist())
            except zipfile.BadZipFile:
                tem_conteudo = True  # não é zip; mantém como veio
            if not tem_conteudo:
                tmp.unlink()
                return {"status": "vazio", "detalhe": "sem movimento (não salvo)"}
            sufixo = Path(d.suggested_filename or "").suffix or ".zip"
            arquivo = destino / (Path(nome_arquivo).stem + sufixo)
            tmp.replace(arquivo)  # replace sobrescreve se já existir (Windows)
            return _fin({"status": "baixado", "detalhe": arquivo.name})
    except PWTimeout:
        # só grava diagnóstico quando o download REALMENTE falhou (após as tentativas)
        try:
            page.screenshot(path=f"debug_export_{lado}_{formato}.png", full_page=True)
            with open(f"debug_acoes_{lado}_{formato}.txt", "w", encoding="utf-8") as fh:
                fh.write(page.evaluate(JS_DEBUG_ACOES, par) or "")
        except Exception:
            pass
        return {"status": "erro", "detalhe": "download não veio (ver debug_acoes_*.txt)"}


def baixar_xmls_relatorio_cliente(page, comp_label, comp_dot, pasta_cliente, com_movimento):
    """Baixa XMLs (zip) e relatório (PDF) SÓ das modalidades com movimento (detectado no comprovante)."""
    resultados = []
    for lado, modal in (("prestador", "PRESTADOR"), ("tomador", "TOMADOR")):
        if modal not in com_movimento:
            resultados.append({"modalidade": modal[:4], "status": "sem mov"})
            continue
        destino = pasta_cliente / comp_dot / modal.capitalize()
        for formato, nome in (("XML", f"XMLS {modal} - {comp_dot}.zip"),
                              ("PDF", f"RELATORIO {modal} - {comp_dot}.pdf")):
            r = exportar_declaracao(page, lado, formato, comp_label, destino, nome)
            if r["status"] in ("erro", "timeout"):          # transitório -> tenta 1x mais
                r = exportar_declaracao(page, lado, formato, comp_label, destino, nome)
            st = r["status"]
            if st in ("erro", "timeout", "vazio"):          # mostra o motivo no log
                st += f" ({(r.get('detalhe') or '')[:34]})"
            resultados.append({"modalidade": f"{modal[:4]}/{formato}", "status": st})
    return resultados


def main():
    ap = argparse.ArgumentParser(description="Baixar guias (DAM) em lote — GissOnline Guarulhos")
    ap.add_argument("--clientes", required=True, help="lista de clientes .csv OU .xlsx")
    ap.add_argument("--competencia", metavar="MM/AAAA", help="Competência (ex.: 07/2026). Padrão: mês anterior")
    ap.add_argument("--saida", default="documentos", help="pasta raiz de saída (padrão: documentos)")
    ap.add_argument("--headed", action="store_true", help="mostra a janela (padrão headless; o comprovante EXIGE headless)")
    ap.add_argument("--xml", action="store_true", help="também baixa XMLs (zip) + relatório (xlsx) via Exportar declaração")
    ap.add_argument("--limite", type=int, default=0, help="processa só os N primeiros (teste)")
    ap.add_argument("--empresa-cnpj", help="(procuração) seleciona a empresa por CNPJ")
    args = ap.parse_args()

    label, iso = competencia_alvo(args.competencia)
    comp_dot = label.replace("/", ".")  # 07/2026 -> 07.2026
    clientes = ler_clientes(args.clientes)
    if args.limite:
        clientes = clientes[: args.limite]
    if not clientes:
        sys.exit("Nenhum cliente lido.")
    raiz = Path(args.saida)

    print(f"\n=== Baixar guias + comprovantes · competência {label} · saída '{raiz}/' ===")
    print(f"Clientes: {len(clientes)}\n")

    with sync_playwright() as p:
        nav = p.chromium.launch(headless=not args.headed, slow_mo=120 if args.headed else 0)
        for idx, c in enumerate(clientes, 1):
            nome = c["apelido"] or c["login"]
            print(f"[{idx}/{len(clientes)}] {nome} … ", end="", flush=True)
            ctx = nav.new_context(accept_downloads=True)
            page = ctx.new_page()
            try:
                logar(page, c["login"], c["senha"])
                if page.locator('input[placeholder="Senha"]').count() and page.locator('input[placeholder="Senha"]').first.is_visible():
                    raise RuntimeError("login não efetuado")
                selecionar_empresa(page, nome=c["apelido"], cnpj=(c.get("cnpj") or args.empresa_cnpj))
                esperar_operacao(page)
                # se a planilha tiver responsável, agrupa: documentos/<Responsavel>/<Empresa>/...
                resp = (c.get("responsavel") or "").strip()
                pasta_cli = (raiz / _nome_pasta(resp) / _nome_pasta(nome)) if resp else (raiz / _nome_pasta(nome))
                res_g = baixar_guias_cliente(page, nome, iso, comp_dot, pasta_cli)
                res_c, com_mov = baixar_comprovantes_cliente(page, iso, comp_dot, pasta_cli)
                partes = ["guias[" + ", ".join(f"{r['modalidade']}:{r['status']}" for r in res_g) + "]",
                          "compr[" + ", ".join(f"{r['modalidade']}:{r['status']}" for r in res_c) + "]"]
                if args.xml:
                    res_x = baixar_xmls_relatorio_cliente(page, label, comp_dot, pasta_cli, com_mov)
                    partes.append("xml[" + ", ".join(f"{r['modalidade']}:{r['status']}" for r in res_x) + "]")
                print(" ".join(partes))
                # remove pastas vazias (modalidade sem movimento -> fica só o comprovante)
                for sub in sorted(pasta_cli.rglob("*"), reverse=True):
                    if sub.is_dir() and not any(sub.iterdir()):
                        sub.rmdir()
            except Exception as e:
                import traceback
                try:
                    page.screenshot(path=f"debug_guia_{_nome_pasta(nome)}.png", full_page=True)
                    with open(f"debug_erro_{_nome_pasta(nome)}.txt", "w", encoding="utf-8") as fh:
                        fh.write(traceback.format_exc())
                except Exception:
                    pass
                print(f"ERRO — {str(e).splitlines()[0][:150]}")
            finally:
                ctx.close()
        nav.close()

    print(f"\nPronto. Arquivos em: {raiz.resolve()}")


if __name__ == "__main__":
    main()
