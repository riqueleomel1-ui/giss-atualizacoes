# Encerramento em lote — versão Python (Playwright)

Programa que abre o navegador, loga em cada cliente e encerra (Apura o ISSQN) a competência
do **mês anterior** (Prestador + Tomador). Serve para o cenário **1 senha por cliente**.

## Instalação (uma vez)

```bash
pip install -r requirements.txt
playwright install chromium
```

## Preparar a lista de clientes

Aceita **Excel (.xlsx)** ou **CSV**. Colunas: `apelido | login | senha`.
- **apelido**: um nome pra você achar no relatório (ex.: "Auto Moto Escola Jardim").
- **login**: o que você digita no campo "Usuário" do GissOnline (CPF, CNPJ ou usuário).
- **senha**: a senha daquele cliente.

Pode ter linha de título e cabeçalho — o programa ignora automaticamente linhas de título
(1 coluna) e cabeçalhos (que contenham "login/cpf/cnpj/usuário/apelido"). Modelos prontos:
[`clientes.exemplo.xlsx`](clientes.exemplo.xlsx) e [`clientes.exemplo.csv`](clientes.exemplo.csv).

> 💡 No Excel, formate a coluna do **login/CPF como Texto** para não perder zeros à esquerda.

> ⚠️ **Segurança:** este arquivo tem as senhas dos seus clientes. Guarde só no seu PC,
> nunca mande por e-mail/nuvem e apague quando migrar para procuração. O ideal é sair desse
> modelo assim que a procuração estiver ativa (aí não precisa guardar senha nenhuma).

## Rodar

```bash
# 1) SIMULAÇÃO (padrão): faz tudo e PARA antes de apurar. Não encerra nada.
python encerrar.py --clientes clientes.csv

# 2) Testar só os 2 primeiros, vendo a janela:
python encerrar.py --clientes clientes.csv --limite 2

# 3) ENCERRAR DE VERDADE (só depois de conferir a simulação):
python encerrar.py --clientes clientes.csv --apurar

# 4) Escolher a competência (padrão = mês anterior). Aceita MM/AAAA:
python encerrar.py --clientes clientes.csv --competencia 07/2026
```

```bash
# 5) Encerrar só uma modalidade (padrão: as duas, uma de cada vez):
python encerrar.py --clientes clientes.csv --modalidade tomador     # ou: prestador | ambos
```

> Se o mês escolhido não estiver pendente naquele cliente, o status vem `pulado` e o
> detalhe mostra **o que está em aberto** (ex.: "em aberto neste cliente: Tomador 07/2026").
> Assim você sabe exatamente qual `--competencia`/`--modalidade` usar.

Outras flags: `--headless` (sem janela), `--relatorio arquivo.csv`,
`--empresa-cnpj 00.000.000/0001-00` (para quando houver procuração com várias empresas),
`--data-pagamento DD/MM/AAAA` (ver abaixo).

> 📅 **Competência vencida:** depois do vencimento, o portal exige a **Data Pagamento** antes de
> calcular. O programa preenche sozinho com a **data de hoje** (ou a de `--data-pagamento`) e o
> relatório mostra "(vencida, pagamento em DD/MM/AAAA)". Multa/juros, se houver, são calculados
> pelo portal até essa data.

## Saída

No fim gera `relatorio_encerramento.csv` com uma linha por cliente:
`apelido, login, competencia, status, total, detalhe`.

Status possíveis: `simulado`, `encerrado`, `pulado` (competência não pendente), `erro`.

## Observações

- Sempre comece em **simulação**. Só use `--apurar` depois de conferir os totais.
- Se um cliente tiver login/senha errado, ele marca `erro` e segue para o próximo.
- "Apurar" é **irreversível**. O programa nunca clica em Cancelar/excluir.
