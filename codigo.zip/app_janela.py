#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Abre a interface do GISS numa JANELA de aplicativo (sem barra de navegador),
usando pywebview. O servidor é o mesmo do app.py e roda ESCONDIDO em segundo plano:
fechar esta janela NÃO interrompe uma execução — abra de novo e a tela reconecta.
"""
import webview

import app as backend


if __name__ == "__main__":
    url = backend.garantir_servidor()
    if url:
        backend.fechar_console()
        webview.create_window(
            "GISS — Encerramento e Documentos",
            url,
            width=1180, height=860, min_size=(900, 640),
        )
        webview.start()
