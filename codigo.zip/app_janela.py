#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Abre a interface do GISS numa JANELA de aplicativo (sem barra de navegador),
usando pywebview. Por baixo é o mesmo servidor Flask do app.py.
"""
import threading
import time

import webview

import app as backend


def _servidor():
    backend.app.run(host="127.0.0.1", port=backend.PORTA, threaded=True)


if __name__ == "__main__":
    threading.Thread(target=_servidor, daemon=True).start()
    time.sleep(1.2)  # dá tempo do servidor subir
    webview.create_window(
        "GISS — Encerramento e Documentos",
        f"http://127.0.0.1:{backend.PORTA}",
        width=1180, height=860, min_size=(900, 640),
    )
    webview.start()
