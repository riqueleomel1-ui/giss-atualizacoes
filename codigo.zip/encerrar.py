#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Encerramento (Apuração do ISSQN) em lote no GissOnline Guarulhos.

- Alvo: SEMPRE o mês anterior ao atual (ex.: rodando em ago/2026 -> encerra 07/2026).
- Cobre Prestador E Tomador da competência.
- MODO SIMULAÇÃO por padrão: faz tudo até calcular e PARA antes de "Apurar".
  Só encerra de verdade com a flag --apurar.

Uso:
    python encerrar.py --clientes clientes.csv                 # simulação (não encerra)
    python encerrar.py --clientes clientes.csv --apurar        # encerra de verdade
    python encerrar.py --clientes clientes.csv --competencia 2026-07   # força um mês
    python encerrar.py --clientes clientes.csv --headless      # sem janela
    python encerrar.py --clientes clientes.csv --limite 3      # só os 3 primeiros (teste)

Lista de clientes — arquivo .csv OU .xlsx (Excel), uma empresa por linha:
    apelido,login,senha
    Padaria do Ze,12345678000199,minhaSenha
Linhas em branco ou começando com # são ignoradas. Cabeçalho é opcional.
No Excel, formate a coluna do login/CNPJ como TEXTO para não perder zeros à esquerda.

Requisitos:
    pip install -r requirements.txt
    playwright install chromium
"""

import argparse
import csv
import os
import sys
import time
from datetime import date
from pathlib import Path

# Navegador PORTÁTIL: se existir 'sistema/runtime/ms-playwright', usa ele (roda em PC sem
# instalar nada). Importado por baixar_documentos.py e app.py, então vale para todos.
_pw = Path(__file__).resolve().parent / "runtime" / "ms-playwright"
if _pw.is_dir():
    os.environ.setdefault("PLAYWRIGHT_BROWSERS_PATH", str(_pw))

try:
    from playwright.sync_api import sync_playwright, TimeoutError as PWTimeout
except ImportError:
    sys.exit("Playwright não instalado. Rode:  pip install -r requirements.txt  &&  playwright install chromium")

BASE = "https://guarulhos.giss.com.br"
LOGIN_URL = BASE + "/portal/home#/login-portal"

# --- JS reaproveitado do fluxo mapeado -------------------------------------
JS_VALOR_POR_LABEL = """
(labelText) => {
  const norm = s => (s||'').replace(/\\s+/g,' ').replace(/:$/,'').trim().toLowerCase();
  const alvo = norm(labelText);
  const els = Array.from(document.querySelectorAll('label,span,div,strong,b,p,td,th'));
  const lbl = els.find(l => norm(l.textContent) === alvo);
  if(!lbl) return null;
  let sib = lbl.nextElementSibling;
  while(sib){
    if(sib.tagName==='INPUT' && (sib.value||'').trim()) return sib.value.trim();
    const t = (sib.textContent||'').replace(/\\s+/g,' ').trim();
    if(t) return t;
    sib = sib.nextElementSibling;
  }
  const parent = lbl.parentElement;
  if(parent){ const inp = parent.querySelector('input'); if(inp && (inp.value||'').trim()) return inp.value.trim(); }
  return null;
}
"""

JS_SWEETALERT_TEXTO = """
() => {
  const el = document.querySelector('.sweet-alert');
  if (!el) return null;
  const st = getComputedStyle(el);
  // .sweet-alert é position:fixed -> offsetParent é sempre null; use display/visibility.
  if (st.display === 'none' || st.visibility === 'hidden') return null;
  const t = (el.textContent||'').replace(/\\s+/g,' ').trim();
  return t || null;
}
"""

# Detecta o alerta "Informar apenas uma apuração não vencida" em qualquer pop-up visível,
# procurando pela MENSAGEM (robusto à classe do modal; específico o bastante p/ não pegar promo).
JS_ALERTA_APURACAO = """
() => {
  const alvo = ['apenas uma', 'não vencida', 'nao vencida'];
  const els = document.querySelectorAll('.sweet-alert, .swal2-popup, .modal, [role=dialog], .alert, h2, h3, p, div');
  for (const el of els) {
    if (el.offsetParent === null) continue;
    const t = (el.textContent||'').replace(/\\s+/g,' ').trim();
    if (t.length > 200) continue;
    const low = t.toLowerCase();
    if (alvo.some(a => low.includes(a))) return t;
  }
  return null;
}
"""

# Remove à força modais informativos (Bootstrap) + seus backdrops que bloqueiam cliques.
# NÃO mexe em .sweet-alert (o alerta de sucesso do encerramento é preservado).
JS_FECHAR_MODAIS = """
() => {
  let n = 0;
  document.querySelectorAll('.modal, .modal.fade, .modal.show, .modal.in').forEach(m => {
    const vis = m.offsetParent !== null || getComputedStyle(m).display !== 'none';
    if (vis) { m.classList.remove('show','in'); m.style.display = 'none'; n++; }
  });
  document.querySelectorAll('.modal-backdrop, .fade.modal-backdrop').forEach(b => b.remove());
  document.body.classList.remove('modal-open');
  document.body.style.overflow = '';
  document.body.style.paddingRight = '';
  return n;
}
"""


def competencia_alvo(override: str | None):
    """Retorna (label 'MM/AAAA', iso 'AAAA-MM-01'). Padrão = mês anterior.
    Aceita override em MM/AAAA, AAAA-MM, MM-AAAA, AAAA/MM (ex.: 07/2026)."""
    if override:
        partes = [p for p in override.strip().replace(".", "/").replace("-", "/").split("/") if p]
        if len(partes) != 2:
            sys.exit(f"Competência inválida: '{override}'. Use MM/AAAA (ex.: 07/2026).")
        a, b = partes
        y, m = (int(a), int(b)) if len(a) == 4 else (int(b), int(a))
        if not (1 <= m <= 12) or y < 2000:
            sys.exit(f"Competência inválida: '{override}'. Use MM/AAAA (ex.: 07/2026).")
    else:
        hoje = date.today()
        y = hoje.year if hoje.month > 1 else hoje.year - 1
        m = hoje.month - 1 or 12
    return f"{m:02d}/{y}", f"{y}-{m:02d}-01"


def _id_para_competencia(cbid: str):
    """'prestado_2026-07-01' -> '07/2026'."""
    try:
        y, m, _ = cbid.split("_", 1)[1].split("-")
        return f"{int(m):02d}/{y}"
    except Exception:
        return None


def _norm_cel(v):
    """Normaliza uma célula. Evita que CNPJ/senha numérica vire '123.0'."""
    if v is None:
        return ""
    if isinstance(v, float) and v.is_integer():
        return str(int(v))
    return str(v).strip()


def _sem_acento(s: str) -> str:
    import unicodedata
    return "".join(c for c in unicodedata.normalize("NFKD", s or "") if not unicodedata.combining(c))


# Como reconhecer cada coluna pelo NOME no cabeçalho (acento/caixa ignorados).
_HDR_TESTES = {
    "login":       lambda h: "login" in h or "usuario" in h,
    "senha":       lambda h: "senha" in h,
    "cnpj":        lambda h: "cnpj" in h,
    "apelido":     lambda h: "empresa" in h or "razao" in h or "cliente" in h or h == "nome",
    "responsavel": lambda h: "respons" in h or "colaborador" in h,
}


def _mapa_colunas(linhas):
    """Acha a linha de CABEÇALHO e devolve ({campo: índice}, idx_da_linha).
    Só aceita como cabeçalho a linha que tenha, no mínimo, LOGIN e SENHA."""
    for idx, cels in enumerate(linhas):
        low = [_sem_acento(_norm_cel(c)).lower() for c in cels]
        mapa = {}
        for campo, testa in _HDR_TESTES.items():
            for i, h in enumerate(low):
                if h and i not in mapa.values() and testa(h):
                    mapa[campo] = i
                    break
        if "login" in mapa and "senha" in mapa:
            return mapa, idx
    return None, -1


# Fallback quando NÃO há cabeçalho reconhecível: ordem fixa A=Empresa,B=CNPJ,C=Login,D=Senha,E=Responsável.
def _linha_para_cliente(cels):
    cels = [_norm_cel(c) for c in cels]
    while cels and cels[-1] == "":
        cels.pop()
    if not cels or cels[0].startswith("#") or len(cels) < 4:
        return None
    return {"apelido": cels[0], "cnpj": cels[1], "login": cels[2], "senha": cels[3],
            "responsavel": cels[4] if len(cels) >= 5 else ""}


def ler_clientes(caminho: str):
    """Lê clientes de .csv OU .xlsx pelo CABEÇALHO (colunas achadas pelo nome, em qualquer
    ordem): Empresa, CNPJ, Login/CPF, Senha, Responsável. CNPJ e Responsável são opcionais.
    Linha com '#' na 1ª célula = comentário (pulada)."""
    p = Path(caminho)
    if p.suffix.lower() in (".xlsx", ".xlsm"):
        try:
            import openpyxl
        except ImportError:
            sys.exit("Para ler .xlsx instale o openpyxl:  pip install openpyxl")
        wb = openpyxl.load_workbook(p, read_only=True, data_only=True)
        linhas = [list(r) for r in wb.active.iter_rows(values_only=True)]
        wb.close()
    else:
        with open(p, encoding="utf-8-sig", newline="") as f:
            linhas = [row for row in csv.reader(f)]

    mapa, hidx = _mapa_colunas(linhas)
    clientes = []
    if mapa:
        def campo(cels, nome):
            i = mapa.get(nome)
            return _norm_cel(cels[i]) if i is not None and i < len(cels) else ""
        for cels in linhas[hidx + 1:]:                 # só o que vem DEPOIS do cabeçalho
            login, senha = campo(cels, "login"), campo(cels, "senha")
            if not login or not senha:
                continue                               # linha vazia/título/sem credencial
            primeira = _norm_cel(cels[0]) if cels else ""
            apelido = campo(cels, "apelido")
            if primeira.startswith("#") or apelido.startswith("#"):
                continue                               # comentário
            clientes.append({"apelido": apelido, "login": login, "senha": senha,
                             "cnpj": campo(cels, "cnpj"), "responsavel": campo(cels, "responsavel")})
        return clientes

    # sem cabeçalho -> ordem fixa (fallback)
    for cels in linhas:
        r = _linha_para_cliente(cels)
        if r:
            clientes.append(r)
    return clientes


def fechar_modais(page):
    """Dispensa pop-ups informativos (Migração, Suporte, Pesquisa de Satisfação, etc.)."""
    # 1) tenta fechar clicando (educado) — botões seguros só
    for nome in ("OK", "Fechar", "Close"):
        try:
            btns = page.get_by_role("button", name=nome, exact=True)
            for i in range(min(btns.count(), 4)):
                b = btns.nth(i)
                if b.is_visible():
                    b.click(timeout=600)
        except Exception:
            pass
    # 2) remove à força qualquer modal/backdrop informativo que sobrou (o que bloqueia cliques)
    try:
        page.evaluate(JS_FECHAR_MODAIS)
    except Exception:
        pass


def logar(page, login: str, senha: str):
    page.goto(LOGIN_URL, wait_until="domcontentloaded")
    page.wait_for_timeout(1500)
    fechar_modais(page)  # tira os promos que cobrem o formulário
    page.wait_for_selector('input[placeholder="Usuário"]', timeout=10000)
    fechar_modais(page)
    page.fill('input[placeholder="Usuário"]', login)
    page.fill('input[placeholder="Senha"]', senha)
    fechar_modais(page)  # caso algum promo tenha reaparecido antes do clique
    page.get_by_role("button", name="Acessar", exact=True).first.click()
    # espera SAIR do login: aparece a seleção de empresa OU já a área de operação
    try:
        page.wait_for_selector(
            '[aria-label="Selecionar Empresa"], [title="Selecionar Empresa"], a[href="#/operacao/apuracao"]',
            timeout=15000)
    except PWTimeout:
        pass
    page.wait_for_timeout(800)
    fechar_modais(page)


# A ação de selecionar é um ÍCONE de seta; o texto "Selecionar Empresa" vem do aria-label/title.
SEL_BOTAO_EMPRESA = ('[aria-label="Selecionar Empresa"], [title="Selecionar Empresa"], '
                     'td:last-child a, td:last-child button')


# Escolhe a empresa na tela "Selecione uma empresa" quando o login tem VÁRIAS.
# Recebe [nome, cnpj]: tenta casar por CNPJ (dígitos, mais confiável) e, se não vier
# CNPJ ou ele não bater, casa por coincidência de palavras do NOME. 1 empresa -> entra
# direto. Erra (não pega a primeira) se houver várias e nada casar.
# Retorna {ok, via, motivo, nomes[]} — nomes serve para a mensagem de erro.
JS_ESCOLHER_EMPRESA = r"""
([nome, cnpj]) => {
  const norm = s => (s||'').normalize('NFKD').replace(/[̀-ͯ]/g,'')
                     .toUpperCase()
                     .replace(/([0-9])([A-Z])/g,'$1 $2').replace(/([A-Z])([0-9])/g,'$1 $2')
                     .replace(/[^A-Z0-9]+/g,' ').trim();
  const STOP = new Set(['LTDA','ME','EPP','EIRELI','MEI','SA','EI','CIA','DE','DA','DO','DOS',
    'DAS','E','EM','MUNICIPIO','GUARULHOS','INSCRICAO','MUNICIPAL','CNPJ','CPF']);
  const toks = s => norm(s).split(' ').filter(t => t.length >= 2 && !STOP.has(t) && !/^\d+$/.test(t));
  const digs = s => ((s||'').match(/\d/g)||[]).join('');
  const SEL = '[aria-label="Selecionar Empresa"],[title="Selecionar Empresa"], td:last-child a, td:last-child button';
  const btns = Array.from(document.querySelectorAll(SEL));
  const linhas = []; const vistos = new Set();
  for (const b of btns) {
    const tr = b.closest('tr') || b.closest('li') || b.parentElement;
    if (!tr || vistos.has(tr)) continue;
    vistos.add(tr);
    linhas.push({btn: b, txt: tr.textContent || ''});
  }
  const nomes = linhas.map(l => norm(l.txt).slice(0,80));
  if (linhas.length === 0) return {ok:false, motivo:'nenhuma empresa na tela', nomes};
  if (linhas.length === 1) { linhas[0].btn.click(); return {ok:true, via:'única', nomes}; }
  // várias empresas -> precisa casar
  const cnpjD = digs(cnpj);
  if (cnpjD.length >= 14) {                            // 1) por CNPJ (14 dígitos)
    for (const l of linhas) if (digs(l.txt).includes(cnpjD)) { l.btn.click(); return {ok:true, via:'cnpj', nomes}; }
  }
  const alvoT = new Set(toks(nome));                   // 2) por NOME (coincidência de palavras)
  if (alvoT.size === 0) return {ok:false, motivo:'várias empresas e sem CNPJ/nome que case', nomes};
  let melhor=null, s1=-1, s2=-1;
  for (const l of linhas) {
    const rt = new Set(toks(l.txt));
    let sc=0; for (const t of alvoT) if (rt.has(t)) sc++;
    if (sc > s1) { s2=s1; s1=sc; melhor=l; } else if (sc > s2) { s2=sc; }
  }
  if (s1 <= 0) return {ok:false, motivo:'nome/CNPJ não bateu com nenhuma empresa da tela', nomes};
  if (s1 === s2) return {ok:false, motivo:'ambíguo (empatou entre empresas)', nomes};
  melhor.btn.click();
  return {ok:true, via:'nome', score:s1, nomes};
}
"""


def selecionar_empresa(page, nome: str | None = None, cnpj: str | None = None):
    """Na tela 'Selecione uma empresa'. Quando o login tem VÁRIAS empresas, casa a certa
    por `cnpj` (preferência) ou `nome` (apelido). 1 empresa -> entra direto; várias sem
    casar -> ERRA (em vez de pegar a primeira errada)."""
    try:
        page.wait_for_selector(SEL_BOTAO_EMPRESA, timeout=9000)
    except PWTimeout:
        return  # login já entrou direto numa empresa (sem tela de seleção)
    fechar_modais(page)  # dispensa a Pesquisa de Satisfação que bloqueia o clique
    page.wait_for_timeout(300)

    res = page.evaluate(JS_ESCOLHER_EMPRESA, [nome or "", cnpj or ""]) or {}
    if not res.get("ok"):
        nomes = " | ".join(res.get("nomes") or [])
        raise RuntimeError(
            f"seleção de empresa falhou ({res.get('motivo','?')}) — nome={nome!r} cnpj={cnpj!r}; "
            f"empresas na tela: {nomes}")

    page.wait_for_timeout(1200)
    fechar_modais(page)


def esperar_operacao(page, timeout=10000):
    """Confirma que entramos numa empresa (menu Operação visível)."""
    page.wait_for_selector('a[href="#/operacao/apuracao"]', timeout=timeout)


def dump_debug(page, tag: str):
    """Salva screenshot + texto da tela atual para diagnóstico."""
    safe = "".join(ch if ch.isalnum() else "_" for ch in tag)[:40] or "debug"
    png = f"debug_{safe}.png"
    try:
        page.screenshot(path=png, full_page=True)
    except Exception:
        png = "(sem screenshot)"
    try:
        heads = page.eval_on_selector_all("h1,h2,h3", "els=>els.map(e=>e.textContent.trim()).filter(Boolean).slice(0,10)")
        btns = page.eval_on_selector_all("button", "els=>els.map(e=>e.textContent.trim()).filter(Boolean).slice(0,25)")
        with open(f"debug_{safe}.txt", "w", encoding="utf-8") as f:
            f.write(f"URL: {page.url}\n")
            f.write("TÍTULOS: " + " | ".join(heads) + "\n")
            f.write("BOTÕES: " + " | ".join(btns) + "\n")
    except Exception:
        pass
    return png


def ir_realizar_apuracao(page):
    """Vai para 'Realizar Apuração' clicando no menu (com fallback para o hash)."""
    fechar_modais(page)  # tira qualquer pop-up que bloqueie o menu
    try:
        page.locator('a[href="#/operacao/apuracao"]').first.click(timeout=5000)
        page.wait_for_timeout(500)
    except Exception:
        pass
    try:
        page.locator('a[href="#/operacao/apuracao/realizar"]').first.click(timeout=5000)
    except Exception:
        page.evaluate("location.hash = '#/operacao/apuracao/realizar'")
    page.wait_for_timeout(1500)
    fechar_modais(page)


def _eh_alerta_apenas_uma(texto: str) -> bool:
    """O portal barra apurar duas competências não vencidas juntas."""
    t = (texto or "").lower()
    return "apenas uma" in t or "não vencida" in t or "nao vencida" in t


def _fechar_sweetalert(page, prefer=("Ok", "OK", "Fechar")):
    """Fecha o .sweet-alert clicando no botão preferido (ex.: 'Ok' num alerta, 'Não' no sucesso)."""
    nomes = list(prefer) if isinstance(prefer, (list, tuple)) else [prefer]
    for nome in nomes:
        try:
            b = page.locator(".sweet-alert").get_by_role("button", name=nome, exact=True)
            if b.count() and b.first.is_visible():
                b.first.click(timeout=1500)
                page.wait_for_timeout(300)
                return True
        except Exception:
            pass
    for sel in (".sweet-alert button.confirm", ".sweet-alert button.cancel", ".sweet-alert button"):
        try:
            b = page.locator(sel)
            if b.count() and b.first.is_visible():
                b.first.click(timeout=1500)
                page.wait_for_timeout(300)
                return True
        except Exception:
            pass
    # fallback: botão visível na página inteira (caso o alerta não seja .sweet-alert)
    for nome in nomes:
        try:
            b = page.get_by_role("button", name=nome, exact=True)
            for i in range(min(b.count(), 4)):
                if b.nth(i).is_visible():
                    b.nth(i).click(timeout=1200)
                    page.wait_for_timeout(300)
                    return True
        except Exception:
            pass
    return False


def _ir_competencias(page):
    """Vai até 'Selecione as Competências' (Realizar Apuração -> Detalhar).
    Retorna 'ok', ou um dict 'pulado' se não houver nada a detalhar."""
    ir_realizar_apuracao(page)
    try:
        page.wait_for_selector('button:has-text("Detalhar")', timeout=15000)
    except PWTimeout:
        corpo = ""
        try:
            corpo = (page.inner_text("body") or "").lower()
        except Exception:
            pass
        if any(t in corpo for t in ("nenhum registro", "não há", "nao ha", "sem registros")):
            return {"status": "pulado", "detalhe": "sem apuração pendente (nada a detalhar)", "total": ""}
        raise RuntimeError("não encontrei o botão 'Detalhar' na tela de Apuração")
    fechar_modais(page)
    page.get_by_role("button", name="Detalhar", exact=True).first.click()
    page.wait_for_selector('button:has-text("Calcular")', timeout=20000)
    # As grades (checkboxes das competências) carregam por AJAX DEPOIS do botão Calcular.
    # Espera aparecer algum checkbox; se em ~8s não vier nenhum, aí sim não há pendência.
    try:
        page.wait_for_selector("input[type=checkbox]", timeout=8000)
    except PWTimeout:
        pass
    page.wait_for_timeout(600)
    fechar_modais(page)
    return "ok"


# O <input> é escondido pelo Bootstrap custom-checkbox; disparamos o .click() nativo via JS
# (aciona o ng-click do AngularJS). Setar .checked NÃO funciona.
_MARCAR_JS = ("id => { const el = document.getElementById(id); if (!el) return false; "
              "if (!el.checked) el.click(); return el.checked; }")


def _marcar_calcular(page, iso, mods):
    """Marca as modalidades (mods) e clica Calcular. Retorna:
    ('ok', None) extrato pronto | ('alerta', txt) portal barrou | ('timeout', None) cálculo não retornou."""
    for mod in mods:
        page.evaluate(_MARCAR_JS, f"{mod}_{iso}")
    page.wait_for_timeout(500)
    if not page.evaluate("document.querySelectorAll('input[type=checkbox]:checked').length"):
        raise RuntimeError("nenhuma competência ficou selecionada")
    page.get_by_role("button", name="Calcular", exact=True).first.click()
    # Calcular pode demorar em clientes com MUITAS NOTAS; espera o Extrato (Apurar) OU um alerta.
    for _ in range(200):  # ~60s
        alerta = page.evaluate(JS_ALERTA_APURACAO)
        if alerta:
            return ("alerta", alerta)
        if page.locator('button:has-text("Apurar")').count() > 0:
            return ("ok", None)
        page.wait_for_timeout(300)
    return ("timeout", None)


def _finalizar_extrato(page, label, apurar, desc):
    """No Extrato: espera carregar, lê o Total e (se apurar) clica Apurar. Retorna dict de resultado."""
    page.wait_for_selector('button:has-text("Apurar")', timeout=20000)
    try:
        page.wait_for_load_state("networkidle", timeout=10000)
    except PWTimeout:
        pass
    try:
        page.wait_for_selector("text=Total a Pagar", timeout=8000)
    except PWTimeout:
        pass
    total = ""
    for _ in range(10):  # o extrato pode demorar a renderizar
        total = page.evaluate(JS_VALOR_POR_LABEL, "Total a Pagar") or ""
        if total:
            break
        page.wait_for_timeout(500)

    if not apurar:
        return {"status": "simulado", "detalhe": f"encerraria {label} ({desc})", "total": total}

    page.get_by_role("button", name="Apurar", exact=True).first.click()
    # A apuração pode levar um tempo pra processar (clientes com notas); espera o "sucesso" por ~60s.
    txt = ""
    for _ in range(200):
        txt = page.evaluate(JS_SWEETALERT_TEXTO) or ""
        if txt:
            break
        page.wait_for_timeout(300)
    if "sucesso" in txt.lower():
        _fechar_sweetalert(page, prefer=("Não",))  # fica na tela; guia se imprime depois
        return {"status": "encerrado", "detalhe": f"{label} apurado ({desc})", "total": total}
    raise RuntimeError(f"retorno inesperado ao apurar: {(txt or '')[:120]}")


def _apurar_separado(page, iso, label, apurar):
    """Apura Prestador e Tomador SEPARADAMENTE (quando o portal não deixa os dois juntos)."""
    nomes = {"prestado": "Prestador", "comprado": "Tomador"}
    partes, totais, ok_algum = [], [], False
    for mod in ("prestado", "comprado"):
        estado = _ir_competencias(page)
        if isinstance(estado, dict):
            break
        if page.locator(f"#{mod}_{iso}").count() == 0:
            continue  # essa modalidade não tem a competência (ou já foi encerrada)
        tipo, alerta = _marcar_calcular(page, iso, [mod])
        if tipo == "alerta":
            _fechar_sweetalert(page, prefer=("Ok", "OK"))
            partes.append(f"{nomes[mod]}: alerta ({(alerta or '')[:40]})")
            continue
        if tipo == "timeout":
            partes.append(f"{nomes[mod]}: cálculo não retornou (timeout)")
            continue
        r = _finalizar_extrato(page, label, apurar, desc=nomes[mod])
        partes.append(f"{nomes[mod]}: {r['status']} R$ {r.get('total') or '?'}")
        if r.get("total"):
            totais.append(r["total"])
        ok_algum = True
    if not partes:
        return {"status": "pulado", "detalhe": f"{label} nada pendente", "total": ""}
    status = ("encerrado" if apurar else "simulado") if ok_algum else "erro"
    return {"status": status, "detalhe": f"{label} [separado] " + " | ".join(partes),
            "total": " / ".join(totais)}


def encerrar_competencia(page, iso: str, label: str, apurar: bool):
    """Realizar Apuração -> competências. Apura SEMPRE uma modalidade por vez (Prestador e
    depois Tomador): uniforme para todos os clientes e compatível com quem tem movimento no
    tomador (o portal barra as duas não-vencidas juntas com 'apenas uma apuração não vencida')."""
    estado = _ir_competencias(page)
    if isinstance(estado, dict):
        return estado

    tem_p = page.locator(f"#prestado_{iso}").count() > 0
    tem_t = page.locator(f"#comprado_{iso}").count() > 0
    if not tem_p and not tem_t:
        try:
            ids = page.eval_on_selector_all("input[type=checkbox]", "els=>els.map(e=>e.id).filter(Boolean)")
        except Exception:
            ids = []
        meses = sorted({c for c in (_id_para_competencia(i) for i in ids) if c})
        extra = ("; em aberto neste cliente: " + ", ".join(meses)) if meses else "; nenhuma competência em aberto"
        return {"status": "pulado", "detalhe": f"competência {label} não está pendente{extra}", "total": ""}

    return _apurar_separado(page, iso, label, apurar)


def main():
    ap = argparse.ArgumentParser(description="Encerramento (Apuração ISSQN) em lote — GissOnline Guarulhos")
    ap.add_argument("--clientes", required=True, help="lista de clientes .csv OU .xlsx (colunas apelido,login,senha)")
    ap.add_argument("--apurar", action="store_true", help="ENCERRA DE VERDADE (sem isso, só simula)")
    ap.add_argument("--competencia", metavar="MM/AAAA", help="Competência a encerrar (ex.: 07/2026). Padrão: mês anterior")
    ap.add_argument("--headless", action="store_true", help="Roda sem abrir janela")
    ap.add_argument("--limite", type=int, default=0, help="Processa só os N primeiros (teste)")
    ap.add_argument("--empresa-cnpj", help="(procuração) seleciona a empresa por CNPJ na tela de seleção")
    ap.add_argument("--relatorio", default="relatorio_encerramento.csv", help="arquivo de saída")
    args = ap.parse_args()

    label, iso = competencia_alvo(args.competencia)
    clientes = ler_clientes(args.clientes)
    if args.limite:
        clientes = clientes[: args.limite]
    if not clientes:
        sys.exit("Nenhum cliente lido do CSV.")

    modo = "ENCERRAMENTO REAL" if args.apurar else "SIMULAÇÃO (não encerra)"
    print(f"\n=== Encerramento GissOnline · competência-alvo {label} · {modo} ===")
    if not args.competencia:
        print(f"(padrão = mês anterior. Para escolher outro: --competencia MM/AAAA, ex.: --competencia 07/2026)")
    print(f"Clientes: {len(clientes)}\n")

    resultados = []
    with sync_playwright() as p:
        navegador = p.chromium.launch(headless=args.headless, slow_mo=0 if args.headless else 120)
        for idx, c in enumerate(clientes, 1):
            nome = c["apelido"] or c["login"]
            print(f"[{idx}/{len(clientes)}] {nome} … ", end="", flush=True)
            ctx = navegador.new_context()
            page = ctx.new_page()
            r = {"apelido": nome, "login": c["login"], "competencia": label}
            try:
                logar(page, c["login"], c["senha"])
                # detecta falha de login (formulário ainda presente)
                if page.locator('input[placeholder="Senha"]').count() > 0 and page.locator('input[placeholder="Senha"]').first.is_visible():
                    raise RuntimeError("login não efetuado (confira usuário/senha)")
                selecionar_empresa(page, nome=c["apelido"], cnpj=(c.get("cnpj") or args.empresa_cnpj))
                try:
                    esperar_operacao(page)  # confirma que entrou na empresa
                except PWTimeout:
                    raise RuntimeError("não entrei na área da empresa (login ou seleção de empresa falhou)")
                out = encerrar_competencia(page, iso, label, args.apurar)
                r.update(out)
                # print do Extrato (simulação) ou do resultado (encerrado) para conferência
                if out.get("status") in ("simulado", "encerrado"):
                    try:
                        safe = "".join(ch if ch.isalnum() else "_" for ch in nome)[:40] or "cliente"
                        prefixo = "simulacao" if out["status"] == "simulado" else "encerrado"
                        shot = f"{prefixo}_{safe}.png"
                        page.screenshot(path=shot, full_page=True)
                        r["debug"] = shot
                    except Exception:
                        pass
            except Exception as e:
                png = dump_debug(page, nome)  # screenshot da tela onde travou
                r.update({"status": "erro", "detalhe": str(e).splitlines()[0][:180], "total": r.get("total", ""), "debug": png})
            finally:
                ctx.close()
            extra = f' [screenshot: {r["debug"]}]' if r.get("debug") else ""
            print(f'{r.get("status","?").upper()} — {r.get("detalhe","")} (Total R$ {r.get("total","")}){extra}')
            resultados.append(r)
        navegador.close()

    # relatório
    campos = ["apelido", "login", "competencia", "status", "total", "detalhe", "debug"]
    with open(args.relatorio, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=campos, extrasaction="ignore")
        w.writeheader()
        for r in resultados:
            w.writerow(r)

    resumo = {}
    for r in resultados:
        resumo[r["status"]] = resumo.get(r["status"], 0) + 1
    print("\n=== Resumo ===")
    for k, v in resumo.items():
        print(f"  {k}: {v}")
    print(f"\nRelatório salvo em: {args.relatorio}")


if __name__ == "__main__":
    main()
